package com.aicameratracking.pro.tracking

import android.graphics.RectF

class KalmanBoxTracker(initialRect: RectF) {
    private val state = FloatArray(8) { 0f }
    private val variance = FloatArray(8) { 10f }

    private val processNoise = floatArrayOf(
        0.5f, 0.5f, 0.3f, 0.3f,
        1.5f, 1.5f, 0.8f, 0.8f
    )
    private val measurementNoise = floatArrayOf(4.0f, 4.0f, 6.0f, 6.0f)

    var hitStreak: Int = 0
    var age: Int = 0
    var timeSinceUpdate: Int = 0

    init {
        state[0] = initialRect.centerX()
        state[1] = initialRect.centerY()
        state[2] = initialRect.width()
        state[3] = initialRect.height()
        state[4] = 0f
        state[5] = 0f
        state[6] = 0f
        state[7] = 0f
        hitStreak = 1
    }

    fun predict(): RectF {
        for (i in 0..3) {
            state[i] += state[i + 4]
            variance[i] += processNoise[i] + variance[i + 4]
            variance[i + 4] += processNoise[i + 4]
        }
        age++
        timeSinceUpdate++
        return getEstimatedRect()
    }

    fun update(rect: RectF) {
        timeSinceUpdate = 0
        hitStreak++

        val measurement = floatArrayOf(rect.centerX(), rect.centerY(), rect.width(), rect.height())

        for (i in 0..3) {
            val kalmanGain = variance[i] / (variance[i] + measurementNoise[i])
            val residual = measurement[i] - state[i]
            state[i] += kalmanGain * residual
            variance[i] *= (1f - kalmanGain)
            state[i + 4] += (kalmanGain * residual * 0.3f)
        }
    }

    /** Correct the estimated target geometry after a digital sensor-crop movement. */
    fun compensate(oldCrop: FramingState, newCrop: FramingState,
                   frameWidth: Int, frameHeight: Int, rotation: Int,
                   sensorWidth: Int, sensorHeight: Int) {
        val rect = getEstimatedRect()
        val mapped = FramingMath.compensateRect(rect.left, rect.top, rect.right, rect.bottom,
            frameWidth, frameHeight, rotation, sensorWidth, sensorHeight, oldCrop, newCrop)
        state[0] = (mapped[0] + mapped[2]) / 2f
        state[1] = (mapped[1] + mapped[3]) / 2f
        state[2] = (mapped[2] - mapped[0]).coerceAtLeast(2f)
        state[3] = (mapped[3] - mapped[1]).coerceAtLeast(2f)
        val factor = newCrop.zoom / oldCrop.zoom.coerceAtLeast(1f)
        for (i in 4..7) state[i] *= factor
    }

    fun getEstimatedRect(): RectF {
        val cx = state[0]
        val cy = state[1]
        val w = state[2].coerceAtLeast(10f)
        val h = state[3].coerceAtLeast(10f)
        return RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }
}
