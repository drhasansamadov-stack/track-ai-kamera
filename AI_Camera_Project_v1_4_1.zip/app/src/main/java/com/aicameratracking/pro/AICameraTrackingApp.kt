package com.aicameratracking.pro

import android.app.Application
import com.aicameratracking.pro.data.TrackingDatabase

class AICameraTrackingApp : Application() {
    val database: TrackingDatabase by lazy { TrackingDatabase.getInstance(this) }
}
