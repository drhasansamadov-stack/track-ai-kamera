package com.aicameratracking.pro.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: TrackingMemoryEntity): Long

    @Query("SELECT * FROM tracking_memory ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<TrackingMemoryEntity>>

    @Query("DELETE FROM tracking_memory")
    suspend fun clearMemories()

    @Query("SELECT * FROM app_preferences WHERE id = 1 LIMIT 1")
    fun getPreferences(): Flow<UserTrackingPreferences?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePreferences(prefs: UserTrackingPreferences)
}
