package com.aicameratracking.pro.tracking

import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** One selected detection, with defensive association through brief occlusions. */
enum class TrackingState { IDLE, SEARCHING, LOCKED, LOST }

data class ActiveTrack(
    val rect: RectF,
    val label: String,
    val confidence: Float,
    val state: TrackingState,
    val missedFrames: Int
)

class TargetTracker {
    private var kalmanTracker: KalmanBoxTracker? = null
    private var lockedLabel: String = ""
    private var lockedTrackingId: Int? = null
    private var currentConfidence: Float = 0f
    private var missedFrames = 0
    private val maxToleratedMisses = 60

    var currentState: TrackingState = TrackingState.IDLE
        private set

    fun lockTarget(rect: RectF, label: String, confidence: Float, trackingId: Int? = null) {
        kalmanTracker = KalmanBoxTracker(rect)
        lockedLabel = label
        lockedTrackingId = trackingId
        currentConfidence = confidence
        missedFrames = 0
        currentState = TrackingState.LOCKED
    }

    fun currentTrack(): ActiveTrack? {
        val tracked = kalmanTracker ?: return null
        return ActiveTrack(tracked.getEstimatedRect(), lockedLabel,
            currentConfidence, currentState, missedFrames)
    }

    /**
     * Tap near the *visible* detection box; choose the closest box rather than
     * always the first detection. The margin is supplied in analysis coordinates.
     * Does not invent a target when no detection is nearby.
     */
    fun selectTargetAt(
        tapPoint: PointF,
        detectedTargets: List<DetectedTarget>,
        touchTolerancePx: Float = 0f
    ): Boolean {
        val margin = touchTolerancePx.coerceIn(0f, 120f)
        val hit = detectedTargets.asSequence().mapNotNull { candidate ->
            val rect = candidate.boundingBox
            if (rect.width() <= 0f || rect.height() <= 0f) return@mapNotNull null
            val dx = max(0f, max(rect.left - tapPoint.x, tapPoint.x - rect.right))
            val dy = max(0f, max(rect.top - tapPoint.y, tapPoint.y - rect.bottom))
            val distance = hypot(dx, dy)
            if (distance > margin) return@mapNotNull null
            // Closest boundary wins. When multiple boxes contain the tap,
            // prefer the smaller box (e.g., face rather than full person).
            val area = rect.width() * rect.height()
            Triple(candidate, distance, area)
        }.minWithOrNull(compareBy<Triple<DetectedTarget, Float, Float>> { it.second }
            .thenBy { it.third })?.first

        if (hit == null) return false
        lockTarget(hit.boundingBox, hit.label, hit.confidence, hit.trackingId)
        return true
    }

    fun compensate(oldCrop: FramingState, newCrop: FramingState,
                   frameWidth: Int, frameHeight: Int, rotation: Int,
                   sensorWidth: Int, sensorHeight: Int) {
        kalmanTracker?.compensate(oldCrop, newCrop, frameWidth, frameHeight,
            rotation, sensorWidth, sensorHeight)
    }

    fun cancelTracking() {
        kalmanTracker = null
        lockedTrackingId = null
        currentState = TrackingState.IDLE
        missedFrames = 0
    }

    fun processFrame(detectedTargets: List<DetectedTarget>): ActiveTrack? {
        val tracker = kalmanTracker ?: return null
        val predictedRect = tracker.predict()
        val pWidth = predictedRect.width().coerceAtLeast(1f)
        val pHeight = predictedRect.height().coerceAtLeast(1f)
        val pDiag = hypot(pWidth, pHeight)
        var best: DetectedTarget? = null
        var bestScore = Float.NEGATIVE_INFINITY

        for (candidate in detectedTargets) {
            val rect = candidate.boundingBox
            if (rect.width() <= 0f || rect.height() <= 0f) continue
            val iou = ObjectDetectorPipeline.calculateIoU(predictedRect, rect)
            val centerDistance = hypot(rect.centerX()-predictedRect.centerX(),
                rect.centerY()-predictedRect.centerY())
            val distanceRatio = centerDistance / pDiag.coerceAtLeast(1f)
            val sameLabel = candidate.label == lockedLabel
            val sameId = lockedTrackingId != null && sameLabel && candidate.trackingId == lockedTrackingId
            val scaleRatio = max(rect.width()/pWidth, rect.height()/pHeight)
            val reverseRatio = max(pWidth/rect.width(), pHeight/rect.height())
            if (max(scaleRatio, reverseRatio) > 3.5f) continue
            // IDs are strong but only within the same semantic detector class.
            // Guard against wild jumps: ML Kit IDs can be recycled.
            val eligible = if (sameId) distanceRatio < 2.0f else
                sameLabel && (iou > 0.10f || distanceRatio < 0.66f)
            if (!eligible) continue
            val score = 2.5f*iou + (if (sameId) 1.5f else 0f) +
                (if (sameLabel) 0.35f else 0f) - 0.4f*distanceRatio
            if (score > bestScore) {
                bestScore = score
                best = candidate
            }
        }

        if (best != null) {
            tracker.update(best.boundingBox)
            lockedTrackingId = best.trackingId ?: lockedTrackingId
            currentConfidence = currentConfidence*0.6f + best.confidence*0.4f
            missedFrames = 0
            currentState = TrackingState.LOCKED
        } else {
            missedFrames++
            currentConfidence = (currentConfidence * 0.90f).coerceAtLeast(0f)
            currentState = if (missedFrames > maxToleratedMisses) TrackingState.LOST
                           else if (missedFrames > 3) TrackingState.SEARCHING
                           else TrackingState.LOCKED
        }
        return currentTrack()
    }
}
