package com.aicameratracking.pro.tracking

import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Camera2 pan/zoom servo: detection callback updates an absolute sensor-space goal;
 * independent 30 Hz ticks move the crop smoothly, without reusing stale frame errors.
 * Hardware may ignore SCALER_CROP_REGION when CameraX owns the crop: test on device.
 */
class AutoFramingController {
    private var state = FramingState(0.5f, 0.5f, 1f)
    private var goalX = 0.5f
    private var goalY = 0.5f
    private var desiredZoom = 1f
    private var velocityX = 0f
    private var velocityY = 0f
    private var lastTickNs = 0L
    private var lastSeenNs = 0L
    private var targetPresent = false
    var minZoom = 1f
    var maxZoom = 8f
    var autoZoomEnabled = true

    fun reset() {
        state = FramingState(0.5f, 0.5f, minZoom.coerceAtLeast(1f))
        desiredZoom = state.zoom
        goalX = 0.5f; goalY = 0.5f
        velocityX = 0f; velocityY = 0f
        lastTickNs = 0L; lastSeenNs = 0L; targetPresent = false
    }

    fun state(): FramingState = state

    fun setZoom(value: Float) {
        state = FramingMath.clamp(state.copy(zoom = value), minZoom, maxZoom)
        desiredZoom = state.zoom
    }

    /** Supply VERIFIED detections only; predictions are not evidence for camera movement. */
    fun observe(rect: RectF?, frameWidth: Int, frameHeight: Int, rotation: Int,
                sensorWidth: Int, sensorHeight: Int, verified: Boolean,
                nowNs: Long = System.nanoTime()) {
        if (!verified || rect == null || frameWidth <= 0 || frameHeight <= 0 ||
            rect.width() <= 1f || rect.height() <= 1f) return
        val cx = rect.centerX() / frameWidth - 0.5f
        val cy = rect.centerY() / frameHeight - 0.5f
        if (!cx.isFinite() || !cy.isFinite()) return
        val (spanX, spanY) = FramingMath.sensorStreamSpans(frameWidth, frameHeight,
            rotation, sensorWidth, sensorHeight)
        val (errorSensorX, errorSensorY) = FramingMath.analysisErrorToSensor(
            cx, cy, rotation, spanX, spanY)
        // The target location is kept in full-sensor coordinates. The 30Hz timer
        // must never integrate the same stale image error repeatedly.
        goalX = (state.centerX + errorSensorX / state.zoom).coerceIn(0f, 1f)
        goalY = (state.centerY + errorSensorY / state.zoom).coerceIn(0f, 1f)
        val fraction = max(rect.width() / frameWidth, rect.height() / frameHeight)
        if (fraction.isFinite() && fraction > 0.002f) {
            val targetZoom = (state.zoom * (0.33f / fraction)).coerceIn(minZoom, maxZoom)
            // Re-centering at 1x has zero crop margin. Gradual preparatory zoom
            // creates the room needed to pan, even for edge-of-screen targets.
            desiredZoom = if (autoZoomEnabled) targetZoom else state.zoom
        }
        targetPresent = true
        lastSeenNs = nowNs
    }

    fun tick(nowNs: Long = System.nanoTime()): FramingState {
        val dt = if (lastTickNs == 0L) 1f / 30f else
            ((nowNs - lastTickNs) / 1_000_000_000f).coerceIn(0.008f, 0.1f)
        lastTickNs = nowNs
        val elapsed = if (lastSeenNs == 0L) Float.POSITIVE_INFINITY else
            ((nowNs - lastSeenNs) / 1_000_000_000f).coerceAtLeast(0f)
        // Do not chase stale boxes during occlusions; later widen gradually.
        if (!targetPresent || elapsed > 0.50f) {
            velocityX *= (1f - 6f * dt).coerceIn(0f, 1f)
            velocityY *= (1f - 6f * dt).coerceIn(0f, 1f)
            if (elapsed > 2.0f) desiredZoom = minZoom.coerceAtLeast(1f)
        } else {
            val dead = 0.018f / state.zoom
            val dx = goalX - state.centerX
            val dy = goalY - state.centerY
            val wantedVX = if (abs(dx) <= dead) 0f else dx * 4.2f
            val wantedVY = if (abs(dy) <= dead) 0f else dy * 4.2f
            val limit = 0.85f / state.zoom.coerceAtLeast(1f)
            val wx = wantedVX.coerceIn(-limit, limit)
            val wy = wantedVY.coerceIn(-limit, limit)
            // Velocity easing and bounded acceleration, preventing hard jumps.
            val accel = 2.1f * dt / state.zoom.coerceAtLeast(1f)
            velocityX += (wx - velocityX).coerceIn(-accel, accel)
            velocityY += (wy - velocityY).coerceIn(-accel, accel)
        }
        val x = state.centerX + velocityX * dt
        val y = state.centerY + velocityY * dt
        // Log-domain zoom makes relative zoom speed consistent at 1x and 6x.
        val z = state.zoom.coerceAtLeast(1f)
        val wantedLog = ln(desiredZoom.coerceIn(minZoom, maxZoom).coerceAtLeast(1f))
        val diff = wantedLog - ln(z)
        val rate = if (diff >= 0f) 0.50f else 0.68f
        val nextZoom = exp(ln(z) + diff.coerceIn(-rate * dt, rate * dt))
        state = FramingMath.clamp(FramingState(x, y, nextZoom), minZoom, maxZoom)
        return state
    }
}
