package com.aicameratracking.pro.ui

import android.app.Application
import android.graphics.PointF
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aicameratracking.pro.AICameraTrackingApp
import com.aicameratracking.pro.audio.MotorAudioSynthesizer
import com.aicameratracking.pro.camera.PhysicalCameraLens
import com.aicameratracking.pro.data.TrackingMemoryEntity
import com.aicameratracking.pro.data.UserTrackingPreferences
import com.aicameratracking.pro.tracking.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiCameraState(
    val activeTrack: ActiveTrack? = null,
    val detectedCount: Int = 0,
    val isRecording: Boolean = false,
    val zoomRatio: Float = 1.0f,
    val minZoom: Float = 1.0f,
    val maxZoom: Float = 1.0f,
    val isAutoZoomEnabled: Boolean = true,
    val isAutoCenterEnabled: Boolean = false,
    val isAutoCaptureEnabled: Boolean = false,
    val isSoundEnabled: Boolean = true,
    val isAiMemoryEnabled: Boolean = true,
    val statusMessage: String = "Hazırdır",
    val availableLenses: List<PhysicalCameraLens> = emptyList(),
    val currentLens: PhysicalCameraLens? = null,
    val language: String = "AZ",
    val memoryItems: List<TrackingMemoryEntity> = emptyList()
)

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val db = (application as AICameraTrackingApp).database.trackingDao()
    private val targetTracker = TargetTracker()
    private val autoZoomController = AutoZoomController()
    val audioSynthesizer = MotorAudioSynthesizer()

    private val _uiState = MutableStateFlow(UiCameraState())
    val uiState: StateFlow<UiCameraState> = _uiState.asStateFlow()

    private var trackingStartTime = 0L
    private var lastAutoCaptureTime = 0L
    private var lockedSince = 0L

    init {
        audioSynthesizer.start()

        viewModelScope.launch {
            db.getPreferences().collect { prefs ->
                if (prefs != null) {
                    _uiState.update {
                        it.copy(
                            isAiMemoryEnabled = prefs.isAiMemoryEnabled,
                            isAutoZoomEnabled = prefs.isAutoZoomEnabled,
                            isSoundEnabled = prefs.isSoundEnabled,
                            language = prefs.preferredLanguage
                        )
                    }
                    autoZoomController.isEnabled = prefs.isAutoZoomEnabled
                    audioSynthesizer.isMuted = !prefs.isSoundEnabled
                } else {
                    db.savePreferences(UserTrackingPreferences())
                }
            }
        }

        viewModelScope.launch {
            db.getAllMemories().collect { list ->
                _uiState.update { it.copy(memoryItems = list) }
            }
        }
    }

    fun onLensesDiscovered(lenses: List<PhysicalCameraLens>, initial: PhysicalCameraLens?) {
        _uiState.update { it.copy(availableLenses = lenses, currentLens = initial) }
    }

    fun setZoomBounds(minZoom: Float, maxZoom: Float, currentZoom: Float) {
        val safeMin = minZoom.coerceAtLeast(1f)
        val safeMax = maxZoom.coerceAtLeast(safeMin)
        val safeCurrent = currentZoom.coerceIn(safeMin, safeMax)
        autoZoomController.minHardwareZoomRatio = safeMin
        autoZoomController.maxHardwareZoomRatio = safeMax
        autoZoomController.currentHardwareZoomRatio = safeCurrent
        _uiState.update { it.copy(minZoom = safeMin, maxZoom = safeMax, zoomRatio = safeCurrent) }
    }

    fun onFrameAnalyzed(
        detected: List<DetectedTarget>,
        sensorWidth: Int,
        sensorHeight: Int,
        applyZoomToCamera: (Float) -> Unit,
        applyAutoFrame: (ActiveTrack?, Int, Int, Int) -> Float?,
        rotationDegrees: Int,
        triggerAutoPhoto: () -> Unit
    ) {
        val track = targetTracker.processFrame(detected)
        val now = System.currentTimeMillis()
        if (track?.state == TrackingState.LOCKED && track.missedFrames == 0) {
            if (lockedSince == 0L) lockedSince = now
        } else {
            lockedSince = 0L
        }

        _uiState.update {
            it.copy(
                activeTrack = track,
                detectedCount = detected.size,
                statusMessage = when (track?.state) {
                    TrackingState.LOCKED -> if (it.language == "AZ") "HƏDƏF KİLİDLƏNDİ" else "TARGET LOCKED"
                    TrackingState.SEARCHING -> if (it.language == "AZ") "HƏDƏF İTDİ — AXTARILIR" else "TARGET LOST — SEARCHING"
                    TrackingState.LOST -> if (it.language == "AZ") "HƏDƏF İTİRİLDİ" else "TARGET LOST"
                    else -> if (it.language == "AZ") "Gözləmədə" else "Idle"
                }
            )
        }

        if (_uiState.value.isAutoCenterEnabled) {
            val centeredZoom = applyAutoFrame(track, sensorWidth, sensorHeight, rotationDegrees)
            if (centeredZoom != null && centeredZoom.isFinite()) {
                _uiState.update { it.copy(zoomRatio = centeredZoom) }
            }
            // Crop speed is controlled by a separate 30 Hz ticker. Use observed
            // zoom delta here only for a subtle motor sound, not fake animation.
            val lastZoom = autoZoomController.currentHardwareZoomRatio
            if (centeredZoom != null) {
                audioSynthesizer.updateMotorSpeed(kotlin.math.abs(centeredZoom - lastZoom))
                autoZoomController.currentHardwareZoomRatio = centeredZoom
            }
        } else if (autoZoomController.isEnabled && track != null) {
            val (newZoom, velocity) = autoZoomController.calculateTargetZoom(
                track.rect,
                sensorWidth.toFloat(),
                sensorHeight.toFloat(),
                track.state
            )

            if (newZoom != autoZoomController.currentHardwareZoomRatio) {
                autoZoomController.currentHardwareZoomRatio = newZoom
                applyZoomToCamera(newZoom)
                _uiState.update { it.copy(zoomRatio = newZoom) }
                audioSynthesizer.updateMotorSpeed(velocity)
            } else {
                audioSynthesizer.updateMotorSpeed(0f)
            }
        } else {
            audioSynthesizer.updateMotorSpeed(0f)
        }

        if (_uiState.value.isAutoCaptureEnabled && track?.state == TrackingState.LOCKED) {
            if (lockedSince != 0L && now - lockedSince >= 800L &&
                now - lastAutoCaptureTime > 3500L && track.confidence > 0.70f) {
                lastAutoCaptureTime = now
                triggerAutoPhoto()
            }
        }
    }

    /** Reproject the tracker after Camera2 physically changes its crop window. */
    fun compensateCrop(oldCrop: FramingState, newCrop: FramingState,
                       frameWidth: Int, frameHeight: Int, rotation: Int,
                       sensorWidth: Int, sensorHeight: Int) {
        targetTracker.compensate(oldCrop, newCrop, frameWidth, frameHeight,
            rotation, sensorWidth, sensorHeight)
        _uiState.update { it.copy(activeTrack = targetTracker.currentTrack(), zoomRatio = newCrop.zoom) }
    }

    fun syncAutoCenter(enabled: Boolean) {
        _uiState.update { it.copy(isAutoCenterEnabled = enabled) }
    }

    fun onScreenTapped(
        tapPoint: PointF,
        currentCandidates: List<DetectedTarget>,
        tolerance: Float
    ): Boolean {
        lockedSince = 0L
        val success = targetTracker.selectTargetAt(tapPoint, currentCandidates, tolerance)
        if (success) {
            trackingStartTime = System.currentTimeMillis()
            val newTrack = targetTracker.currentTrack()
            _uiState.update {
                it.copy(
                    activeTrack = newTrack,
                    statusMessage = if (it.language == "AZ") "HƏDƏF SEÇİLDİ" else "TARGET SELECTED"
                )
            }
        } else {
            _uiState.update {
                it.copy(statusMessage = if (it.language == "AZ")
                    "OBYEKT TAPILMADI — ÇƏRÇİVƏYƏ TOXUN" else "NO OBJECT — TAP NEAR A BOX")
            }
        }
        return success
    }

    fun unlockTarget() {
        lockedSince = 0L
        val currentTrack = _uiState.value.activeTrack
        if (currentTrack != null && _uiState.value.isAiMemoryEnabled) {
            val duration = System.currentTimeMillis() - trackingStartTime
            if (duration > 1500L) {
                viewModelScope.launch {
                    db.insertMemory(
                        TrackingMemoryEntity(
                            targetType = currentTrack.label,
                            initialConfidence = currentTrack.confidence,
                            averageZoomLevel = _uiState.value.zoomRatio,
                            trackedDurationMs = duration,
                            lastKnownAspectRatio = currentTrack.rect.width() / currentTrack.rect.height()
                        )
                    )
                }
            }
        }
        targetTracker.cancelTracking()
        _uiState.update { it.copy(activeTrack = null) }
    }

    fun setManualZoom(zoom: Float, applyZoomToCamera: (Float) -> Unit) {
        autoZoomController.currentHardwareZoomRatio = zoom
        applyZoomToCamera(zoom)
        _uiState.update { it.copy(zoomRatio = zoom) }
    }

    fun toggleAutoCenter(setCameraMode: (Boolean) -> Boolean) {
        val desired = !_uiState.value.isAutoCenterEnabled
        val actual = setCameraMode(desired)
        _uiState.update {
            it.copy(isAutoCenterEnabled = actual,
                statusMessage = if (desired && !actual) {
                    if (it.language == "AZ") "AUTO CENTER BU KAMERADA DƏSTƏKLƏNMİR"
                    else "AUTO CENTER NOT SUPPORTED"
                } else if (actual) {
                    if (it.language == "AZ") "AUTO CENTER AKTİVDİR (SINAQ)"
                    else "AUTO CENTER ACTIVE (EXPERIMENTAL)"
                } else {
                    if (it.language == "AZ") "AUTO CENTER SÖNDÜRÜLDÜ" else "AUTO CENTER DISABLED"
                }
            )
        }
    }

    fun toggleAutoZoom() {
        val newState = !_uiState.value.isAutoZoomEnabled
        autoZoomController.isEnabled = newState
        _uiState.update { it.copy(isAutoZoomEnabled = newState) }
        savePreferences()
    }

    fun toggleSound() {
        val newState = !_uiState.value.isSoundEnabled
        audioSynthesizer.isMuted = !newState
        _uiState.update { it.copy(isSoundEnabled = newState) }
        savePreferences()
    }

    fun toggleAiMemory() {
        _uiState.update { it.copy(isAiMemoryEnabled = !it.isAiMemoryEnabled) }
        savePreferences()
    }

    fun toggleAutoCapture() {
        _uiState.update { it.copy(isAutoCaptureEnabled = !it.isAutoCaptureEnabled) }
    }

    fun toggleLanguage() {
        val nextLang = if (_uiState.value.language == "AZ") "EN" else "AZ"
        _uiState.update { it.copy(language = nextLang) }
        savePreferences()
    }

    private fun savePreferences() {
        val state = _uiState.value
        viewModelScope.launch {
            db.savePreferences(UserTrackingPreferences(
                isAiMemoryEnabled = state.isAiMemoryEnabled,
                isAutoZoomEnabled = state.isAutoZoomEnabled,
                isSoundEnabled = state.isSoundEnabled,
                preferredLanguage = state.language
            ))
        }
    }

    fun clearMemory() {
        viewModelScope.launch {
            db.clearMemories()
        }
    }

    fun updateRecordingState(isRec: Boolean) {
        _uiState.update { it.copy(isRecording = isRec) }
    }

    override fun onCleared() {
        super.onCleared()
        audioSynthesizer.release()
    }
}
