package com.aicameratracking.pro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracking_memory")
data class TrackingMemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val targetType: String,
    val initialConfidence: Float,
    val averageZoomLevel: Float,
    val trackedDurationMs: Long,
    val lastKnownAspectRatio: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_preferences")
data class UserTrackingPreferences(
    @PrimaryKey val id: Int = 1,
    val isAiMemoryEnabled: Boolean = true,
    val isAutoZoomEnabled: Boolean = true,
    val isSoundEnabled: Boolean = true,
    val preferredLanguage: String = "AZ",
    val detectionThreshold: Float = 0.55f,
    val zoomDeadzone: Float = 0.04f,
    val targetRatioScreenLongest: Float = 0.33f
)
