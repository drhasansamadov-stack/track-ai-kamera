package com.aicameratracking.pro.tracking

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** All coordinates are fractions of the full active sensor, not screen pixels. */
data class FramingState(val centerX: Float, val centerY: Float, val zoom: Float)

/** Pure geometry shared by crop control and tracker ego-motion correction. */
object FramingMath {
    fun sensorStreamSpans(imageWidth: Int, imageHeight: Int, rotation: Int,
                          sensorWidth: Int, sensorHeight: Int): Pair<Float, Float> {
        if (imageWidth <= 0 || imageHeight <= 0 || sensorWidth <= 0 || sensorHeight <= 0) return 1f to 1f
        val normalizedRotation = ((rotation % 360) + 360) % 360
        val streamAspect = if (normalizedRotation == 90 || normalizedRotation == 270)
            imageHeight.toFloat() / imageWidth else imageWidth.toFloat() / imageHeight
        val sensorAspect = sensorWidth.toFloat() / sensorHeight
        return if (streamAspect >= sensorAspect) 1f to (sensorAspect / streamAspect).coerceIn(0.01f, 1f)
               else (streamAspect / sensorAspect).coerceIn(0.01f, 1f) to 1f
    }

    /** ImageAnalysis coordinates (already rotated upright) to a full-sensor offset. */
    fun analysisErrorToSensor(errorX: Float, errorY: Float, rotation: Int,
                              spanX: Float, spanY: Float): Pair<Float, Float> {
        return when (((rotation % 360) + 360) % 360) {
            90 -> errorY * spanX to -errorX * spanY
            180 -> -errorX * spanX to -errorY * spanY
            270 -> -errorY * spanX to errorX * spanY
            else -> errorX * spanX to errorY * spanY
        }
    }

    fun sensorErrorToAnalysis(errorX: Float, errorY: Float, rotation: Int,
                              spanX: Float, spanY: Float): Pair<Float, Float> {
        val x = errorX / spanX.coerceAtLeast(0.01f)
        val y = errorY / spanY.coerceAtLeast(0.01f)
        return when (((rotation % 360) + 360) % 360) {
            90 -> -y to x
            180 -> -x to -y
            270 -> y to -x
            else -> x to y
        }
    }

    fun clamp(state: FramingState, minZoom: Float, maxZoom: Float): FramingState {
        val z = state.zoom.coerceIn(max(1f, minZoom), max(maxZoom, max(1f, minZoom)))
        val half = 0.5f / z
        return FramingState(state.centerX.coerceIn(half, 1f - half),
                            state.centerY.coerceIn(half, 1f - half), z)
    }

    /** Reproject a rectangle measured in the old crop into a changed preview crop. */
    fun compensateRect(left: Float, top: Float, right: Float, bottom: Float,
                       imageWidth: Int, imageHeight: Int, rotation: Int,
                       sensorWidth: Int, sensorHeight: Int,
                       oldCrop: FramingState, newCrop: FramingState): FloatArray {
        if (imageWidth <= 0 || imageHeight <= 0) return floatArrayOf(left, top, right, bottom)
        val (spanX, spanY) = sensorStreamSpans(imageWidth, imageHeight, rotation, sensorWidth, sensorHeight)
        fun point(x: Float, y: Float): Pair<Float, Float> {
            val dx = x / imageWidth - 0.5f
            val dy = y / imageHeight - 0.5f
            val (nativeX, nativeY) = analysisErrorToSensor(dx, dy, rotation, spanX, spanY)
            val sensorX = oldCrop.centerX + nativeX / oldCrop.zoom
            val sensorY = oldCrop.centerY + nativeY / oldCrop.zoom
            val (newX, newY) = sensorErrorToAnalysis(
                (sensorX - newCrop.centerX) * newCrop.zoom,
                (sensorY - newCrop.centerY) * newCrop.zoom,
                rotation, spanX, spanY)
            return (newX + 0.5f) * imageWidth to (newY + 0.5f) * imageHeight
        }
        val a = point(left, top)
        val b = point(right, bottom)
        return floatArrayOf(min(a.first, b.first), min(a.second, b.second),
                            max(a.first, b.first), max(a.second, b.second))
    }
}
