package com.aicameratracking.pro.ui

import android.widget.Toast
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.aicameratracking.pro.camera.CameraManager
import com.aicameratracking.pro.tracking.DetectedTarget
import com.aicameratracking.pro.tracking.ObjectDetectorPipeline
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(viewModel: CameraViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val uiState by viewModel.uiState.collectAsState()
    val textMeasurer = rememberTextMeasurer()

    var showMemorySheet by remember { mutableStateOf(false) }
    var currentCandidates by remember { mutableStateOf<List<DetectedTarget>>(emptyList()) }
    var frameWidth by remember { mutableIntStateOf(1080) }
    var frameHeight by remember { mutableIntStateOf(1920) }
    var frameRotation by remember { mutableIntStateOf(0) }

    val cameraManager = remember { CameraManager(context, lifecycleOwner) }
    LaunchedEffect(uiState.isAutoZoomEnabled) {
        cameraManager.setAutoZoomEnabled(uiState.isAutoZoomEnabled)
    }

    val detectorPipeline = remember { ObjectDetectorPipeline { detected, width, height, rotation ->
            frameRotation = rotation
            frameWidth = width
            frameHeight = height
            currentCandidates = detected

            viewModel.onFrameAnalyzed(
                detected = detected,
                sensorWidth = width,
                sensorHeight = height,
                applyZoomToCamera = { newZoom -> cameraManager.setZoomRatio(newZoom) },
                applyAutoFrame = { track, w, h, rot -> cameraManager.updateAutoCenter(track, w, h, rot) },
                rotationDegrees = rotation,
                triggerAutoPhoto = {
                    cameraManager.takePhoto(
                        onSuccess = { name ->
                            Toast.makeText(context, "AI Auto Photo: $name", Toast.LENGTH_SHORT).show()
                        },
                        onError = {}
                    )
                }
            )
        } }

    // Main-thread framing callback: compensate Kalman state for the crop movement.
    // Inference frames may have latency, so hardware testing is essential.
    val latestGeometry = rememberUpdatedState(Triple(frameWidth, frameHeight, frameRotation))
    DisposableEffect(Unit) {
        cameraManager.setOnFramingChanged { oldCrop, newCrop, sensorWidth, sensorHeight ->
            val (w, h, rot) = latestGeometry.value
            viewModel.compensateCrop(oldCrop, newCrop, w, h, rot, sensorWidth, sensorHeight)
        }
        cameraManager.initialize(detectorPipeline) { supportedLenses ->
            viewModel.onLensesDiscovered(supportedLenses, cameraManager.currentLens)
            viewModel.syncAutoCenter(cameraManager.isAutoCenterEnabled())
            cameraManager.getZoomState()?.observe(lifecycleOwner) { zoom ->
                if (zoom != null) {
                    viewModel.setZoomBounds(zoom.minZoomRatio, zoom.maxZoomRatio, zoom.zoomRatio)
                }
            }
        }

        onDispose {
            cameraManager.release()
            detectorPipeline.close()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                    cameraManager.setSurfaceProvider(this.surfaceProvider)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        OverlayCanvas(
            activeTrack = uiState.activeTrack,
            allDetected = currentCandidates,
            sensorWidth = frameWidth,
            sensorHeight = frameHeight,
            isFrontCamera = cameraManager.currentLensFacing == androidx.camera.core.CameraSelector.LENS_FACING_FRONT,
            onTap = { point, tolerance ->
                if (!viewModel.onScreenTapped(point, currentCandidates, tolerance)) {
                    detectorPipeline.startRegionAt(point)?.let { region ->
                        viewModel.onScreenTapped(point, listOf(region), 0f)
                    }
                }
            },
            textMeasurer = textMeasurer
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .background(
                                if (uiState.activeTrack != null) Color(0xFF00E676) else Color.Yellow,
                                CircleShape
                            )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = uiState.statusMessage,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { viewModel.toggleAutoZoom() },
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (uiState.isAutoZoomEnabled) Color(0xFF00E676).copy(alpha = 0.3f) else Color.Black.copy(alpha = 0.5f),
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomIn,
                        contentDescription = "Auto Zoom",
                        tint = if (uiState.isAutoZoomEnabled) Color(0xFF00E676) else Color.White
                    )
                }

                IconButton(
                    onClick = {
                        viewModel.toggleAutoCenter { enabled -> cameraManager.setAutoCenterEnabled(enabled) }
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (uiState.isAutoCenterEnabled) Color(0xFF00E676).copy(alpha = 0.3f)
                            else Color.Black.copy(alpha = 0.5f), CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.CenterFocusStrong,
                        contentDescription = "Experimental Auto Center",
                        tint = if (uiState.isAutoCenterEnabled) Color(0xFF00E676) else Color.White
                    )
                }

                IconButton(
                    onClick = { viewModel.toggleSound() },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (uiState.isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "Sound",
                        tint = Color.White
                    )
                }

                IconButton(
                    onClick = { showMemorySheet = true },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(Icons.Default.Memory, contentDescription = "AI Memory", tint = Color.White)
                }

                IconButton(
                    onClick = { viewModel.toggleLanguage() },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Text(text = uiState.language, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 110.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                for (lens in uiState.availableLenses) {
                    val isSelected = uiState.currentLens?.id == lens.id
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color.White else Color.Transparent)
                            .clickable {
                                viewModel.onLensesDiscovered(uiState.availableLenses, lens)
                                // Use the existing detector and refresh preview through CameraManager.
                                detectorPipeline.resetRegionTracker()
                                cameraManager.switchLens(lens, detectorPipeline)
                                viewModel.onLensesDiscovered(uiState.availableLenses, lens)
                                viewModel.syncAutoCenter(cameraManager.isAutoCenterEnabled())
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = lens.title,
                            color = if (isSelected) Color.Black else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format(Locale.US, "%.1fx", uiState.zoomRatio),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Slider(
                    value = uiState.zoomRatio,
                    onValueChange = { targetZoom ->
                        viewModel.setManualZoom(targetZoom) { z -> cameraManager.setZoomRatio(z) }
                    },
                    valueRange = uiState.minZoom..uiState.maxZoom,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E676),
                        activeTrackColor = Color(0xFF00E676)
                    )
                )
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 16.dp, start = 20.dp, end = 20.dp)
        ) {
            Column(
                modifier = Modifier.align(Alignment.CenterStart),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                IconButton(
                    onClick = { viewModel.toggleAutoCapture() },
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            if (uiState.isAutoCaptureEnabled) Color(0xFF00E676) else Color.DarkGray.copy(alpha = 0.7f),
                            CircleShape
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoMode,
                        contentDescription = "Auto Capture",
                        tint = if (uiState.isAutoCaptureEnabled) Color.Black else Color.White
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (uiState.language == "AZ") "Avto Çəkiliş" else "Auto Capture",
                    color = Color.White,
                    fontSize = 10.sp
                )
            }

            Row(
                modifier = Modifier.align(Alignment.Center),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, Color.White, CircleShape)
                        .clickable {
                            cameraManager.takePhoto(
                                onSuccess = { name ->
                                    Toast.makeText(context, if (uiState.language == "AZ") "Şəkil: $name" else "Photo: $name", Toast.LENGTH_SHORT).show()
                                },
                                onError = { err ->
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(modifier = Modifier.size(60.dp).background(Color.White, CircleShape))
                }

                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(4.dp, if (uiState.isRecording) Color.Red else Color.White, CircleShape)
                        .clickable {
                            cameraManager.toggleRecording(
                                onStarted = { viewModel.updateRecordingState(true) },
                                onFinalized = { name ->
                                    viewModel.updateRecordingState(false)
                                    Toast.makeText(context, if (uiState.language == "AZ") "Video: $name" else "Video: $name", Toast.LENGTH_SHORT).show()
                                },
                                onError = { err ->
                                    viewModel.updateRecordingState(false)
                                    Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (uiState.isRecording) 32.dp else 56.dp)
                            .background(Color.Red, if (uiState.isRecording) RoundedCornerShape(6.dp) else CircleShape)
                    )
                }
            }

            if (uiState.activeTrack != null) {
                Column(
                    modifier = Modifier.align(Alignment.CenterEnd),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    IconButton(
                        onClick = { viewModel.unlockTarget() },
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.Red.copy(alpha = 0.8f), CircleShape)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Unlock", tint = Color.White)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = if (uiState.language == "AZ") "Ləğv Et" else "Unlock",
                        color = Color.White,
                        fontSize = 10.sp
                    )
                }
            }
        }

        if (showMemorySheet) {
            ModalBottomSheet(
                onDismissRequest = { showMemorySheet = false },
                containerColor = Color(0xFF1E1E1E),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.language == "AZ") "Lokal AI Yaddaşı" else "On-Device AI Memory",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = { viewModel.clearMemory() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f))
                        ) {
                            Text(if (uiState.language == "AZ") "Təmizlə" else "Clear")
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (uiState.language == "AZ") "AI Yaddaşı Aktivdir" else "AI Memory Active", modifier = Modifier.weight(1f))
                        Switch(
                            checked = uiState.isAiMemoryEnabled,
                            onCheckedChange = { viewModel.toggleAiMemory() }
                        )
                    }

                    HorizontalDivider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 10.dp))

                    if (uiState.memoryItems.isEmpty()) {
                        Text(
                            text = if (uiState.language == "AZ") "Saxlanılmış izləmə yoxdur." else "No tracked sessions recorded yet.",
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    } else {
                        LazyColumn(modifier = Modifier.height(260.dp)) {
                            items(uiState.memoryItems) { item ->
                                Surface(
                                    color = Color(0xFF2C2C2C),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(text = item.targetType, fontWeight = FontWeight.Bold, color = Color(0xFF00E676))
                                        Text(
                                            text = "Müddət: ${item.trackedDurationMs / 1000}s | Böyütmə: ${String.format(Locale.US, "%.1fx", item.averageZoomLevel)}",
                                            fontSize = 12.sp,
                                            color = Color.LightGray
                                        )
                                        Text(
                                            text = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US).format(Date(item.timestamp)),
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
