package com.aicameratracking.pro.tracking

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Downsampled luminance image rotated to analysis/preview orientation. */
data class GrayFrame(val width: Int, val height: Int, val pixels: ByteArray,
                     val displayWidth: Int, val displayHeight: Int)
data class RegionMatch(val cx: Int, val cy: Int, val radius: Int, val confidence: Float)

/**
 * An honest *appearance-based* tracker for an unclassified user-selected region.
 * No semantic class claims. Does not persist identity across long occlusions,
 * major scale changes or lookalikes; signals failure instead of a fake lock.
 */
class LumaRegionTracker(private val patchRadius: Int = 7) {
    private var template: FloatArray? = null
    private var cx = 0
    private var cy = 0
    private var missing = 0
    private var width = 0
    private var height = 0
    private var lastFrame: GrayFrame? = null
    private var vx = 0f
    private var vy = 0f

    @Synchronized fun reset() {
        template = null; missing = 0; vx = 0f; vy = 0f
    }

    @Synchronized fun acceptFrame(frame: GrayFrame): RegionMatch? {
        lastFrame = frame
        if (template == null) return null
        if (frame.width != width || frame.height != height) { reset(); return null }
        val model = template ?: return null
        val radius = patchRadius
        var bestX = cx
        var bestY = cy
        var best = Double.MAX_VALUE
        val predictedX = cx + vx.toInt().coerceIn(-5, 5)
        val predictedY = cy + vy.toInt().coerceIn(-5, 5)
        val reach = if (missing > 0) min(30, 11 + 3 * missing) else 11
        for (y in max(radius, predictedY - reach)..min(height-radius-1,predictedY+reach) step 2) {
            for (x in max(radius,predictedX-reach)..min(width-radius-1,predictedX+reach) step 2) {
                var sum = 0.0
                var i = 0
                for (dy in -radius..radius step 2) for (dx in -radius..radius step 2) {
                    val pixel = frame.pixels[(y+dy)*width+(x+dx)].toInt() and 0xff
                    sum += abs(pixel - model[i++])
                }
                val score = sum / i
                if (score < best) { best = score; bestX=x;bestY=y }
            }
        }
        // Never accept an arbitrarily poor match. A fully uniform patch cannot
        // initialize this tracker, which avoids tracking blank sky or flat walls.
        if (best > 27.0) {
            missing++
            if (missing > 8) reset()
            return null
        }
        val confidence = (1.0-best / 90.0).toFloat().coerceIn(0f,1f)
        vx = (0.4f * (bestX - cx) + 0.6f * vx).coerceIn(-8f,8f)
        vy = (0.4f * (bestY - cy) + 0.6f * vy).coerceIn(-8f,8f)
        cx = bestX;cy = bestY;missing=0
        // Adapt only for strong matches, limiting template drift.
        if (best < 11.0) {
            var i=0
            for (dy in -radius..radius step 2) for (dx in -radius..radius step 2) {
                val v=(frame.pixels[(cy+dy)*width+(cx+dx)].toInt() and 0xff).toFloat()
                model[i]=model[i]*0.96f+v*0.04f
                i++
            }
        }
        return RegionMatch(cx, cy, radius, confidence)
    }

    /** Call on a tap only if semantic detector had no nearby candidate. */
    @Synchronized fun startAt(displayX: Float, displayY: Float): RegionMatch? {
        val frame = lastFrame ?: return null
        val x = (displayX * frame.width / frame.displayWidth).toInt()
        val y = (displayY * frame.height / frame.displayHeight).toInt()
        val r = patchRadius
        if (x-r < 0 || y-r < 0 || x+r >= frame.width || y+r >= frame.height) return null
        val sampled = ArrayList<Float>()
        for (dy in -r..r step 2) for (dx in -r..r step 2) {
            sampled.add((frame.pixels[(y+dy)*frame.width+(x+dx)].toInt() and 0xff).toFloat())
        }
        val mean = sampled.average()
        val variance = sampled.sumOf { (it-mean)*(it-mean) }.toDouble() / sampled.size
        if (variance < 35.0) return null // no visual texture to hold onto
        template = sampled.toFloatArray()
        width=frame.width;height=frame.height;cx=x;cy=y;missing=0;vx=0f;vy=0f
        return RegionMatch(cx,cy,r,0.8f)
    }

    companion object {
        fun toDetection(match: RegionMatch, frame: GrayFrame): DetectedTarget {
            val scaleX=frame.displayWidth.toFloat()/frame.width
            val scaleY=frame.displayHeight.toFloat()/frame.height
            val radiusPx=(match.radius+2) * max(scaleX,scaleY)
            val x=match.cx*scaleX;val y=match.cy*scaleY
            return DetectedTarget(android.graphics.RectF(x-radiusPx,y-radiusPx,x+radiusPx,y+radiusPx),
                "Seçilmiş sahə", match.confidence, -1000007)
        }
    }
}
