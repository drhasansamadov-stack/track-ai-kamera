package com.aicameratracking.pro.camera

import android.graphics.Matrix
import android.graphics.RectF

object CoordinateTransformer {
    fun inversePoint(
        viewX: Float, viewY: Float,
        sourceWidth: Float, sourceHeight: Float,
        viewWidth: Float, viewHeight: Float,
        isFrontCamera: Boolean
    ): android.graphics.PointF {
        val scale = maxOf(viewWidth / sourceWidth, viewHeight / sourceHeight)
        val dx = (viewWidth - sourceWidth * scale) / 2f
        val dy = (viewHeight - sourceHeight * scale) / 2f
        val x = if (isFrontCamera) viewWidth - viewX else viewX
        return android.graphics.PointF(
            ((x - dx) / scale).coerceIn(0f, sourceWidth),
            ((viewY - dy) / scale).coerceIn(0f, sourceHeight)
        )
    }

    fun transformRect(
        sourceRect: RectF,
        sourceWidth: Float,
        sourceHeight: Float,
        viewWidth: Float,
        viewHeight: Float,
        isFrontCamera: Boolean
    ): RectF {
        val matrix = Matrix()
        val scaleX = viewWidth / sourceWidth
        val scaleY = viewHeight / sourceHeight
        val scale = maxOf(scaleX, scaleY)

        val scaledWidth = sourceWidth * scale
        val scaledHeight = sourceHeight * scale
        val dx = (viewWidth - scaledWidth) / 2f
        val dy = (viewHeight - scaledHeight) / 2f

        matrix.postScale(scale, scale)
        matrix.postTranslate(dx, dy)

        if (isFrontCamera) {
            matrix.postScale(-1f, 1f, viewWidth / 2f, viewHeight / 2f)
        }

        val destination = RectF()
        matrix.mapRect(destination, sourceRect)
        return destination
    }
}
