package com.aicameratracking.pro.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

class MotorAudioSynthesizer {
    private var audioTrack: AudioTrack? = null
    private var isPlaying = false
    private var synthJob: Job? = null
    private val sampleRate = 44100
    private val bufferSize = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    ).coerceAtLeast(1024)

    @Volatile var targetFrequency = 140.0f
    @Volatile var targetAmplitude = 0.0f
    @Volatile var isMuted = false

    fun start() {
        if (isPlaying) return
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()
        isPlaying = true

        synthJob = CoroutineScope(Dispatchers.Default).launch {
            val shortBuffer = ShortArray(bufferSize / 2)
            var phase = 0.0
            var currentAmp = 0.0f
            var currentFreq = 140.0f

            while (isActive && isPlaying) {
                val desiredAmp = if (isMuted) 0f else targetAmplitude
                currentAmp += (desiredAmp - currentAmp) * 0.15f
                currentFreq += (targetFrequency - currentFreq) * 0.15f

                val angularVelocity = 2.0 * Math.PI * currentFreq / sampleRate

                for (i in shortBuffer.indices) {
                    if (currentAmp < 0.001f) {
                        shortBuffer[i] = 0
                    } else {
                        val sampleVal = sin(phase) * 0.75 + sin(3.0 * phase) * 0.25
                        shortBuffer[i] = (sampleVal * currentAmp * Short.MAX_VALUE).toInt().toShort()
                        phase += angularVelocity
                        if (phase > 2.0 * Math.PI) phase -= 2.0 * Math.PI
                    }
                }
                audioTrack?.write(shortBuffer, 0, shortBuffer.size)
            }
        }
    }

    fun updateMotorSpeed(zoomVelocity: Float) {
        val speedMagnitude = abs(zoomVelocity)
        if (speedMagnitude < 0.0005f) {
            targetAmplitude = 0.0f
        } else {
            targetFrequency = (120f + (speedMagnitude * 1200f)).coerceIn(120f, 380f)
            targetAmplitude = (speedMagnitude * 0.45f).coerceIn(0.01f, 0.15f)
        }
    }

    fun release() {
        isPlaying = false
        synthJob?.cancel()
        audioTrack?.let {
            try {
                it.stop()
                it.release()
            } catch (_: Exception) {}
        }
        audioTrack = null
    }
}
