package com.aicameratracking.pro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.aicameratracking.pro.ui.CameraScreen
import com.aicameratracking.pro.ui.CameraViewModel
import com.aicameratracking.pro.ui.theme.AICameraTrackingProTheme

class MainActivity : ComponentActivity() {

    private val viewModel: CameraViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        if (cameraGranted) {
            setupCameraUi()
        } else {
            android.widget.Toast.makeText(this, "Kamera icazəsi tələb olunur", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val requiredPermissions = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )

        val allGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (allGranted) {
            setupCameraUi()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    private fun setupCameraUi() {
        setContent {
            AICameraTrackingProTheme {
                CameraScreen(viewModel = viewModel)
            }
        }
    }
}
