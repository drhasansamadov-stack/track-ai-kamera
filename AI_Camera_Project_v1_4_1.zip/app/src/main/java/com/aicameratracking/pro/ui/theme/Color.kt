package com.aicameratracking.pro.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldGreen = Color(0xFF00E676)
val AlertRed = Color(0xFFFF3D00)
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
