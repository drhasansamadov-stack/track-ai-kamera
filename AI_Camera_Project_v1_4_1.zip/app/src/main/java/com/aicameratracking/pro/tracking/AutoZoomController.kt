package com.aicameratracking.pro.tracking

import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max

/** CameraX zoom is center-anchored; protect off-center targets from cropping. */
class AutoZoomController {
    var isEnabled: Boolean = true
    var currentHardwareZoomRatio: Float = 1.0f
    var minHardwareZoomRatio: Float = 1.0f
    var maxHardwareZoomRatio: Float = 10.0f
    private val targetViewportFraction = 0.33f
    private val deadzone = 0.035f
    private var lastZoomVelocity = 0f

    fun calculateTargetZoom(
        targetRect: RectF?,
        screenWidth: Float,
        screenHeight: Float,
        trackingState: TrackingState
    ): Pair<Float, Float> {
        val current = currentHardwareZoomRatio
        if (!isEnabled || targetRect == null || trackingState == TrackingState.IDLE ||
            screenWidth <= 0f || screenHeight <= 0f) {
            lastZoomVelocity = 0f
            return current to 0f
        }
        if (trackingState == TrackingState.LOST) {
            val ratio = (current - (current-minHardwareZoomRatio)*0.07f)
                .coerceIn(minHardwareZoomRatio, maxHardwareZoomRatio)
            lastZoomVelocity = ratio-current
            return ratio to lastZoomVelocity
        }

        val cx = targetRect.centerX()/screenWidth
        val cy = targetRect.centerY()/screenHeight
        val width = (targetRect.width()/screenWidth).coerceAtLeast(0f)
        val height = (targetRect.height()/screenHeight).coerceAtLeast(0f)
        val fraction = max(width, height)
        if (!cx.isFinite() || !cy.isFinite() || !fraction.isFinite() || fraction <= 0f) {
            lastZoomVelocity = 0f
            return current to 0f
        }

        // Off-center targets cannot be centered by CameraX setZoomRatio().
        // Resist zoom-in, and pull back slightly if a target is near the edge.
        val closeToEdge = targetRect.left < screenWidth * 0.10f ||
            targetRect.right > screenWidth * 0.90f ||
            targetRect.top < screenHeight * 0.10f ||
            targetRect.bottom > screenHeight * 0.90f
        val offCenter = abs(cx-0.5f) > 0.27f || abs(cy-0.5f) > 0.27f
        val error = targetViewportFraction - fraction
        val zoomVelocity = when {
            closeToEdge || offCenter -> -minOf(0.045f, (current-minHardwareZoomRatio)*0.08f)
            abs(error) <= deadzone -> 0f
            else -> (error*current*0.34f).coerceIn(-0.12f, 0.12f)
        }
        // Small steps and damping prevent jumpy control feedback with live frames.
        val smoothed = lastZoomVelocity*0.25f + zoomVelocity*0.75f
        val proposed = (current+smoothed).coerceIn(minHardwareZoomRatio, maxHardwareZoomRatio)
        lastZoomVelocity = proposed-current
        return proposed to lastZoomVelocity
    }
}
