package com.aicameratracking.pro.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Rect
import android.Manifest
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.aicameratracking.pro.tracking.ActiveTrack
import com.aicameratracking.pro.tracking.AutoFramingController
import com.aicameratracking.pro.tracking.FramingState
import com.aicameratracking.pro.tracking.TrackingState
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

data class PhysicalCameraLens(
    val id: String,
    val title: String,
    val selector: CameraSelector,
    val zoomFactor: Float
)

class CameraManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null

    private var pendingSurfaceProvider: Preview.SurfaceProvider? = null
    private var preview: Preview? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null

    private val framing = AutoFramingController()
    private var autoCenterEnabled = false
    private var autoCenterRequested = true
    private val framingHandler = Handler(Looper.getMainLooper())
    private var lastAppliedFraming: FramingState? = null
    private var onFramingChanged: ((FramingState, FramingState, Int, Int) -> Unit)? = null
    private var opticalStabilizationAvailable = false
    private val framingRunnable = object : Runnable {
        override fun run() {
            if (!autoCenterEnabled) return
            val before = framing.state()
            val next = framing.tick()
            if (before != next) applySensorCrop()
            framingHandler.postDelayed(this, 33L)
        }
    }

    fun setOnFramingChanged(callback: ((FramingState, FramingState, Int, Int) -> Unit)?) {
        onFramingChanged = callback
    }
    fun isAutoCenterEnabled(): Boolean = autoCenterEnabled
    fun setAutoZoomEnabled(enabled: Boolean) { framing.autoZoomEnabled = enabled }
    private var camera2Control: Camera2CameraControl? = null
    private var sensorBounds: Rect? = null

    var currentLensFacing: Int = CameraSelector.LENS_FACING_BACK
    var currentLens: PhysicalCameraLens? = null

    fun initialize(
        analyzer: ImageAnalysis.Analyzer,
        onInitialized: (List<PhysicalCameraLens>) -> Unit
    ) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            val lenses = querySupportedLenses(cameraProvider!!)
            currentLens = lenses.firstOrNull()
            startCamera(currentLens?.selector ?: CameraSelector.DEFAULT_BACK_CAMERA, analyzer)
            onInitialized(lenses)
        }, ContextCompat.getMainExecutor(context))
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun querySupportedLenses(provider: ProcessCameraProvider): List<PhysicalCameraLens> {
        val lenses = mutableListOf<PhysicalCameraLens>()
        // CameraX can expose a logical back lens or several selectable devices.
        // Never advertise hidden physical lenses or invented 0.6x/3.2x switches.
        if (provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
            lenses.add(PhysicalCameraLens("back_default", "1x", CameraSelector.DEFAULT_BACK_CAMERA, 1f))
        }
        val infos = provider.availableCameraInfos
        val backCameraIds = infos.mapNotNull { info ->
            try {
                val cam2 = Camera2CameraInfo.from(info)
                val facing = cam2.getCameraCharacteristic(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_BACK) cam2.cameraId else null
            } catch (_: Exception) { null }
        }.distinct()
        if (backCameraIds.size > 1) {
            // Exposed independent cameras only. Some OEMs cannot bind video+analysis
            // to these devices, so startCamera still has its capability fallback.
            backCameraIds.forEachIndexed { index, cameraId ->
                val selector = CameraSelector.Builder().addCameraFilter { candidates ->
                    candidates.filter { info ->
                        try { Camera2CameraInfo.from(info).cameraId == cameraId }
                        catch (_: Exception) { false }
                    }
                }.build()
                try {
                    if (provider.hasCamera(selector)) {
                        lenses.add(PhysicalCameraLens("back_$cameraId", "Arxa ${index + 1}", selector, 1f))
                    }
                } catch (_: Exception) { /* Vendor camera may not be selectable. */ }
            }
        }
        if (provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
            lenses.add(PhysicalCameraLens("front", "Ön", CameraSelector.DEFAULT_FRONT_CAMERA, 1f))
        }
        return lenses
    }

    @OptIn(ExperimentalCamera2Interop::class)
    fun startCamera(cameraSelector: CameraSelector, analyzer: ImageAnalysis.Analyzer) {
        val provider = cameraProvider ?: return
        activeRecording?.stop()
        activeRecording = null
        stopFramingLoop()
        camera2Control = null
        sensorBounds = null
        lastAppliedFraming = null
        framing.reset()
        provider.unbindAll()
        currentLensFacing = cameraSelector.lensFacing ?: CameraSelector.LENS_FACING_BACK

        // EIS can alter the field of view independently for preview and recorded
        // video. Avoid forcing it while software controls the Camera2 crop region.
        val previewBuilder = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9)
        val previewUseCase = previewBuilder.build().also { useCase ->
            pendingSurfaceProvider?.let { useCase.setSurfaceProvider(it) }
        }
        preview = previewUseCase

        val analysisUseCase = ImageAnalysis.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_16_9)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .build().also {
                it.setAnalyzer(cameraExecutor, analyzer)
            }
        imageAnalysis = analysisUseCase

        val photoUseCase = ImageCapture.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_16_9)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
        imageCapture = photoUseCase

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
            .build()
        val videoUseCase = VideoCapture.withOutput(recorder)
        videoCapture = videoUseCase

        try {
            // Some camera devices cannot simultaneously bind four use cases.
            // First attempt full functionality, then gracefully fall back to
            // live detection and still photography without a video recorder.
            camera = provider.bindToLifecycle(
                lifecycleOwner, cameraSelector,
                previewUseCase, analysisUseCase, photoUseCase, videoUseCase
            )
        } catch (fullBindError: Exception) {
            provider.unbindAll()
            videoCapture = null
            try {
                camera = provider.bindToLifecycle(
                    lifecycleOwner, cameraSelector,
                    previewUseCase, analysisUseCase, photoUseCase
                )
            } catch (fallbackError: Exception) {
                android.util.Log.e("AICamera", "Camera initialization failed", fallbackError)
                camera = null
            }
        }

        // Access the actual camera's active sensor rectangle. No advertised
        // centering feature is assumed if the device does not provide this.
        camera?.let { bound ->
            try {
                camera2Control = Camera2CameraControl.from(bound.cameraControl)
                val info = Camera2CameraInfo.from(bound.cameraInfo)
                sensorBounds = info.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
                opticalStabilizationAvailable = info
                    .getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                    ?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
                framing.minZoom = bound.cameraInfo.zoomState.value?.minZoomRatio?.coerceAtLeast(1f) ?: 1f
                framing.maxZoom = bound.cameraInfo.zoomState.value?.maxZoomRatio ?: 8f
                framing.reset()
                if (autoCenterRequested && sensorBounds != null) {
                    autoCenterEnabled = true
                    applySensorCrop()
                    startFramingLoop()
                } else {
                    autoCenterEnabled = false
                }
            } catch (error: Exception) {
                android.util.Log.w("AICamera", "Freeform crop unavailable", error)
                camera2Control = null
                sensorBounds = null
                autoCenterEnabled = false
            }
        }
    }

    fun switchLens(lens: PhysicalCameraLens, analyzer: ImageAnalysis.Analyzer) {
        currentLens = lens
        startCamera(lens.selector, analyzer)
    }

    fun setSurfaceProvider(surfaceProvider: Preview.SurfaceProvider) {
        pendingSurfaceProvider = surfaceProvider
        preview?.setSurfaceProvider(surfaceProvider)
    }

    fun setZoomRatio(ratio: Float) {
        val limits = camera?.cameraInfo?.zoomState?.value
        val safe = if (limits == null) ratio else ratio.coerceIn(limits.minZoomRatio, limits.maxZoomRatio)
        if (autoCenterEnabled && camera2Control != null && sensorBounds != null) {
            framing.setZoom(safe)
            applySensorCrop()
        } else {
            camera?.cameraControl?.setZoomRatio(safe)
        }
    }

    private fun stopFramingLoop() {
        framingHandler.removeCallbacks(framingRunnable)
        autoCenterEnabled = false
    }

    private fun startFramingLoop() {
        framingHandler.removeCallbacks(framingRunnable)
        if (autoCenterEnabled) framingHandler.postDelayed(framingRunnable, 33L)
    }

    /** Camera2 crop is hardware-dependent and must be verified on actual device. */
    fun setAutoCenterEnabled(enabled: Boolean): Boolean {
        autoCenterRequested = enabled
        stopFramingLoop()
        autoCenterEnabled = enabled && camera2Control != null && sensorBounds != null
        if (!autoCenterEnabled) {
            camera2Control?.clearCaptureRequestOptions()
            lastAppliedFraming = null
            framing.reset()
            camera?.cameraControl?.setZoomRatio(1f)
        } else {
            // On API 30+, a non-unit CONTROL_ZOOM_RATIO overrides a freeform crop.
            camera?.cameraControl?.setZoomRatio(1f)
            framing.reset()
            applySensorCrop()
            startFramingLoop()
        }
        return autoCenterEnabled
    }

    /** Called with the analysis frame's *rotation* and actual unrotated sensor dimensions. */
    fun updateAutoCenter(track: ActiveTrack?, frameWidth: Int, frameHeight: Int,
                         rotationDegrees: Int): Float? {
        val sensor = sensorBounds ?: return null
        if (!autoCenterEnabled || camera2Control == null) return null
        framing.observe(track?.rect, frameWidth, frameHeight, rotationDegrees,
            sensor.width(), sensor.height(),
            verified = track != null && track.state == TrackingState.LOCKED && track.missedFrames == 0)
        return framing.state().zoom
    }

    private fun applySensorCrop() {
        val sensor = sensorBounds ?: return
        val control = camera2Control ?: return
        val z = framing.state()
        val w = (sensor.width() / z.zoom).toInt().coerceIn(2, sensor.width())
        val h = (sensor.height() / z.zoom).toInt().coerceIn(2, sensor.height())
        val left = (sensor.left + sensor.width() * z.centerX - w / 2f).toInt()
            .coerceIn(sensor.left, sensor.right - w)
        val top = (sensor.top + sensor.height() * z.centerY - h / 2f).toInt()
            .coerceIn(sensor.top, sensor.bottom - h)
        val crop = Rect(left, top, left + w, top + h)
        val options = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.SCALER_CROP_REGION, crop)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            options.setCaptureRequestOption(CaptureRequest.CONTROL_ZOOM_RATIO, 1f)
        }
        if (opticalStabilizationAvailable) {
            options.setCaptureRequestOption(
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON)
        }
        // Device-specific: CameraX may still own zoom/crop or apply different
        // transformations to preview/video/photo use cases.
        control.setCaptureRequestOptions(options.build())
        val old = lastAppliedFraming
        if (old != null && old != z) {
            onFramingChanged?.invoke(old, z, sensor.width(), sensor.height())
        }
        lastAppliedFraming = z
    }

    fun getZoomState() = camera?.cameraInfo?.zoomState

    fun takePhoto(onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        val capture = imageCapture ?: return
        val fileName = "IMG_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/AICameraTracking")
            }
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    onSuccess(fileName)
                }

                override fun onError(exception: ImageCaptureException) {
                    onError(exception.message ?: "Capture failed")
                }
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun toggleRecording(
        onStarted: () -> Unit,
        onFinalized: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val vc = videoCapture ?: run {
            onError("Video is not supported with simultaneous tracking on this camera")
            return
        }

        if (activeRecording != null) {
            activeRecording?.stop()
            activeRecording = null
            return
        }

        val fileName = "VID_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AICameraTracking")
            }
        }

        val mediaStoreOutputOptions = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(contentValues).build()

        activeRecording = vc.output
            .prepareRecording(context, mediaStoreOutputOptions)
            .apply {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    withAudioEnabled()
                }
            }
            .start(ContextCompat.getMainExecutor(context)) { recordEvent ->
                when (recordEvent) {
                    is VideoRecordEvent.Start -> onStarted()
                    is VideoRecordEvent.Finalize -> {
                        if (!recordEvent.hasError()) {
                            onFinalized(fileName)
                        } else {
                            onError(recordEvent.cause?.message ?: "Recording error")
                        }
                        activeRecording = null
                    }
                }
            }
    }

    fun isRecording(): Boolean = activeRecording != null

    fun release() {
        stopFramingLoop()
        onFramingChanged = null
        activeRecording?.stop()
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
    }
}
