package com.aicameratracking.pro.tracking

import android.graphics.RectF
import org.junit.Assert.*
import org.junit.Test

class AutoFramingControllerTest {
    @Test fun convergesTowardSensorTargetWhileRespectingBounds() {
        val c = AutoFramingController()
        c.maxZoom = 6f
        c.reset()
        val start = 1000000000L
        val initial=c.state()
        for(i in 0..120) {
            val current=c.state()
            val (px,py)=FramingMath.sensorErrorToAnalysis(
                (.5f-current.centerX)*current.zoom,
                (.285f-current.centerY)*current.zoom, 90, 1f, .75f)
            val radius=65f*current.zoom
            val imageX=(px+.5f)*1080f
            val imageY=(py+.5f)*1920f
            if (i%3==0) c.observe(RectF(imageX-radius,imageY-radius,
                imageX+radius,imageY+radius),1080,1920,90,4000,3000,true,
                start+(i+1)*33000000L)
            c.tick(start+(i+1)*33000000L)
        }
        val end=c.state()
        assertTrue(end.zoom>initial.zoom)
        assertTrue(end.centerY<.5f)
        assertTrue(end.centerX in (0.5f/end.zoom)..(1f-.5f/end.zoom))
    }
    @Test fun unverifiedPredictionsDoNotSteerCrop() {
        val c=AutoFramingController()
        c.reset()
        val start=1000000000L
        c.observe(RectF(10f,10f,70f,70f),1080,1920,90,4000,3000,false,start)
        for(i in 0..60) c.tick(start+(i+1)*33000000L)
        val f=c.state()
        assertEquals(1f,f.zoom,0.0001f)
        assertEquals(.5f,f.centerX,0.0001f)
        assertEquals(.5f,f.centerY,0.0001f)
    }
}
