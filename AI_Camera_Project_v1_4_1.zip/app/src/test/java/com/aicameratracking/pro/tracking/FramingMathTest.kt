package com.aicameratracking.pro.tracking

import org.junit.Assert.*
import org.junit.Test

class FramingMathTest {
    @Test fun mappedAxesAreCorrectForPortraitCamera() {
        val (sx, sy) = FramingMath.sensorStreamSpans(1080, 1920, 90, 4000, 3000)
        assertEquals(1f, sx, 0.0001f)
        assertEquals(0.75f, sy, 0.0001f)
        val (dx, dy) = FramingMath.analysisErrorToSensor(0.25f, 0f, 90, sx, sy)
        assertEquals(0f, dx, 0.0001f)
        assertEquals(-0.1875f, dy, 0.0001f)
    }
    @Test fun roundTripAllRotations() {
        for (rot in listOf(0,90,180,270)) {
            val (x,y)=FramingMath.analysisErrorToSensor(0.11f,-0.23f,rot,0.9f,0.8f)
            val (xx,yy)=FramingMath.sensorErrorToAnalysis(x,y,rot,0.9f,0.8f)
            assertEquals(0.11f,xx,0.00001f)
            assertEquals(-0.23f,yy,0.00001f)
        }
    }
    @Test fun cropAlwaysRemainsInsideSensor() {
        for(z in listOf(1f,1.2f,2f,5f,8f)) {
            val v=FramingMath.clamp(FramingState(-3f,4f,z),1f,8f)
            val half=.5f/v.zoom
            assertTrue(v.centerX>=half && v.centerX<=1f-half)
            assertTrue(v.centerY>=half && v.centerY<=1f-half)
        }
    }
    @Test fun croppingReprojectsTrackedBoxesWithoutFakeMovement() {
        for (rot in listOf(0,90,180,270)) {
            val old=FramingState(.5f,.5f,2f)
            val now=FramingState(.55f,.47f,2.4f)
            val a=FramingMath.compensateRect(400f,300f,500f,400f,1080,1920,rot,4000,3000,old,now)
            val b=FramingMath.compensateRect(a[0],a[1],a[2],a[3],1080,1920,rot,4000,3000,now,old)
            assertEquals(400f,b[0],.2f)
            assertEquals(300f,b[1],.2f)
            assertEquals(500f,b[2],.2f)
            assertEquals(400f,b[3],.2f)
        }
    }
}
