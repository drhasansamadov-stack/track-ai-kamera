package com.aicameratracking.pro.tracking

import org.junit.Assert.*
import org.junit.Test

class LumaRegionTrackerTest {
    private fun scene(cx: Int, cy: Int): GrayFrame {
        val w = 128; val h = 96
        val pixels = ByteArray(w*h) { 32 }
        for (y in -10..10) for (x in -10..10) {
            val xx = cx+x; val yy = cy+y
            if (xx in 0 until w && yy in 0 until h)
                pixels[yy*w+xx] = ((x*31 + y*19 + 700) and 255).toByte()
        }
        return GrayFrame(w,h,pixels,w*4,h*4)
    }

    @Test fun selectingEmptyImageFails() {
        val tracker = LumaRegionTracker()
        tracker.acceptFrame(GrayFrame(128,96,ByteArray(128*96),512,384))
        assertNull(tracker.startAt(250f,160f))
    }

    @Test fun followsRealMovingTextureAndCanReset() {
        val tracker = LumaRegionTracker()
        tracker.acceptFrame(scene(60,50))
        assertNotNull(tracker.startAt(240f,200f))
        var matched = 0
        for (i in 0..10) {
            val m = tracker.acceptFrame(scene(60+i,50+i/2))
            if(m != null && m.confidence > .65f) matched++
        }
        assertTrue(matched >= 6)
        tracker.reset()
        assertNull(tracker.acceptFrame(scene(60,50)))
    }
}
