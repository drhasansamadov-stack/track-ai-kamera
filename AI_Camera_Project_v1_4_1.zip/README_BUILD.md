# AI Camera Tracking Pro v1.4.1 — source ZIP

This is a **Kotlin Android project**, NOT a precompiled APK. It extends the
last known successfully compiled v1.3 source; it is not the unreleased Claude
v1.4 source, because that source was not supplied.

## Upload to the existing GitHub repository

The existing `.github/workflows/build-apk.yml` in the repository root unpacks
`AI_Camera_Project.zip` and compiles with JDK 17 / Gradle 8.7 / Android SDK 35.
Upload the separately supplied archive under the **exact filename**
`AI_Camera_Project.zip`, replacing the previous archive in the root of
`drhasansamadov-stack/track-ai-kamera`. A push to `main` triggers the existing
GitHub Actions workflow. Download the APK artifact **only after** `Compile APK`
and `Upload APK` succeed. This is an upgrade for the existing debug app
`com.aicameratracking.pro.debug`, version code 4.

## Implementation included

- Camera rotation + sensor-stream aspect-aware digital pan/zoom coordinate math.
- Separate 30 Hz sensor-crop servo; detection events refresh absolute sensor
  goal instead of integrating the same stale image offset repeatedly.
- Camera2 crop plus 1x CONTROL_ZOOM_RATIO override on Android 11+; request OIS
  only when camera lens claims support. Avoid forced EIS in preview.
- Tracker ego-motion compensation when crop changes; loss has separate
  SEARCHING and LOST statuses, and only verified detections steer crop.
- Wider touch hit margin and an optional local luminance patch tracker for an
  unclassified textured region. It is **not** species/bird classification and
  will struggle with scale changes and occlusion.
- Auto Zoom toggle applies to both centering and ordinary camera modes.
- Additional CameraX-exposed independent back cameras offered when supported;
  avoids inventing unsupported ultra-wide/telephoto zoom labels.

## Verification (as of 2026-10-25)

- Actual local Kotlin compiler: compiled the new pure geometry controller,
  actual tracker and luminance-region tracker with minimal Android RectF stubs.
- Synthetic inputs: 16 geometry/servo assertions; 8 tracker/identity/loss
  assertions; 4 moving-texture/region tracker assertions passed.
- Main Android `assembleDebug`: **NOT RUN** in this environment (no Android SDK).
- Instrumented tests, photo/video parity and on-device Camera2 cropping:
  **NOT RUN**. New code may require a build/error fix on GitHub.

## Known limitations

- The bundled default ML Kit object detector does NOT specifically classify birds;
  a real bird-trained LiteRT/TFLite model and its integration are still needed.
- Appearance-only region tracking is a limited short-range template matcher,
  not robust multi-object re-identification.
- Camera2 `SCALER_CROP_REGION` can be overridden by CameraX or the device and
  may differ between preview/photo/video; capture consistency is unverified.
- Stable video stabilization beyond the shared smoothed crop is not included.
- Camera IDs exposed by CameraX may omit hidden physical OEM lenses.

No false claim of a successful v1.4.1 APK build or physical device test.
