# AI Camera Tracking Pro — extracted Android source

This project was reconstructed from the source-code blocks inside the provided Google AI Studio chat export. It has **not** been successfully compiled or tested on a physical phone. There is no compiled APK in this archive.

## Build using only a phone
1. Create a GitHub repository and add the **contents** of this ZIP (not the ZIP as one file) to the repository. The easiest phone-only option is GitHub Codespaces (browser IDE) or any mobile Git client that can upload folders.
2. Open the repository's **Actions** tab and run **Build AI Camera Tracking Pro APK** manually via `workflow_dispatch`, or push to `main`.
3. If the build is green, open the workflow run's **Artifacts**, download `AICameraTrackingPro-Debug-APK`, extract the artifact ZIP and install `app-debug.apk` on Android.
4. If the build fails, inspect the Actions logs. The error log is essential to fix any dependency or compiler errors.

## Known limitations
- This source contains ML Kit's default object detector and face detector; it does **not** contain a bird-specific custom model. ML Kit default object classification cannot guarantee a distinct bird class.
- Only default front/back cameras are exposed correctly. Other physical camera lens selections were deliberately removed because the original code pointed all of them at the same logical back camera.
- Arbitrary tap-to-track without a matching detected object relies on a manually invented box; this is not a learned visual tracker.
- Zoom and tracking still need real-device testing and tuning. Stored tracking records are not neural-network training.
- Real APK production is dependent on a successful remote Gradle build.

## Additional changes made in this delivery
- Avoid passing nullable CameraX use cases into bindToLifecycle.
- Fallback to preview + object analysis + photo if the phone cannot bind all four use cases. Video is then unavailable rather than silently failing.
- Execute ML Kit frame-result callbacks on the Android main thread.
- Refresh overlay tap handlers when preview dimensions or lens changes.

**These are code-level fixes, not verification of a Gradle build or real-device camera operation.** The Android SDK is not available in the editing environment; GitHub Actions is provided to perform the actual build.
