# AI Camera Tracking Pro v1.3 — experimental auto-centering

This archive contains **native Android Kotlin source code, not an APK**.

## Changes from v1.2
- Added `AutoFramingController.kt`, a bounded crop-controller with a center dead zone, capped pan rate, motion damping and gentle zoom.
- Added **Auto Center** (target-shaped icon) to the Compose camera toolbar. This mode is **opt-in and experimental**.
- Added `Camera2CameraControl` crop-region control using `CaptureRequest.SCALER_CROP_REGION`, with CameraX normal zoom fallback when disabled. Crop updates are throttled.
- Keeps crop position during brief detector dropouts, instead of following predicted rectangles blindly.
- Increments app version to 1.3.0; leaves v1.2 untouched.

## Known limitations, safety and compatibility
- The sensor crop feature is device-dependent and must be validated. Some camera HAL/CameraX combinations may override it. The on-screen enabled indicator shows that the API exists, **not** that the camera applied each request.
- ML Kit frame coordinates and Camera2 sensor crop coordinates need on-device confirmation for each camera. Wrong mappings can cause target drift or reversed pan. If that occurs, TURN OFF Auto Center; normal v1.2 capture behavior remains available.
- Per-zoom captured photos and videos are intended to use the same sensor crop as the preview; the Android API documents propagation to repeating and single capture requests, but results must be tested on the target handset.
- CameraX camera, hardware video stabilization and Camera2 freeform cropping may conflict across models. Testing is necessary.
- The app does NOT have a trained specialized bird classifier or continuous model retraining.
- An algorithm unit test is NOT equivalent to a Gradle build, APK installation, or physical-camera acceptance test.

## Verification done here
- 12 local Kotlin synthetic unit tests passed using a minimal Android `RectF` test double.
- Static reference and ZIP checks performed; full Android SDK/Gradle build was unavailable in this environment.
- **Do not deploy as a replacement for v1.2 without first building and testing on a real device.**

## Compiling in GitHub Actions
The existing repository workflow unpacks `AI_Camera_Project.zip` from its root. To test v1.3, replace that ZIP with the contents of this archive, keeping the root ZIP file name `AI_Camera_Project.zip`. Trigger the same workflow; after build success, download its `AI-Camera-APK` artifact. This requires GitHub repo write access. Do not rename the source ZIP `.apk`.
