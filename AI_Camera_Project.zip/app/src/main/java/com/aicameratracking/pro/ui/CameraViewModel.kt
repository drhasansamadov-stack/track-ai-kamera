package com.aicameratracking.pro.ui

import android.app.Application
import android.graphics.PointF
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aicameratracking.pro.AICameraTrackingApp
import com.aicameratracking.pro.audio.MotorAudioSynthesizer
import com.aicameratracking.pro.camera.PhysicalCameraLens
import com.aicameratracking.pro.data.TrackingMemoryEntity
import com.aicameratracking.pro.data.UserTrackingPreferences
import com.aicameratracking.pro.tracking.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiCameraState(
    val activeTrack: ActiveTrack? = null,
    val detectedCount: Int = 0,
    val isRecording: Boolean = false,
    val zoomRatio: Float = 1.0f,
    val minZoom: Float = 1.0f,
    val maxZoom: Float = 10.0f,
    val isAutoZoomEnabled: Boolean = true,
    val isAutoCaptureEnabled: Boolean = false,
    val isSoundEnabled: Boolean = true,
    val isAiMemoryEnabled: Boolean = true,
    val statusMessage: String = "Hazırdır",
    val availableLenses: List<PhysicalCameraLens> = emptyList(),
    val currentLens: PhysicalCameraLens? = null,
    val language: String = "AZ",
    val memoryItems: List<TrackingMemoryEntity> = emptyList()
)

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val db = (application as AICameraTrackingApp).database.trackingDao()
    private val targetTracker = TargetTracker()
    private val autoZoomController = AutoZoomController()
    val audioSynthesizer = MotorAudioSynthesizer()

    private val _uiState = MutableStateFlow(UiCameraState())
    val uiState: StateFlow<UiCameraState> = _uiState.asStateFlow()

    private var trackingStartTime = 0L
    private var lastAutoCaptureTime = 0L
    private var lockedSince = 0L

    init {
        audioSynthesizer.start()

        viewModelScope.launch {
            db.getPreferences().collect { prefs ->
                if (prefs != null) {
                    _uiState.update {
                        it.copy(
                            isAiMemoryEnabled = prefs.isAiMemoryEnabled,
                            isAutoZoomEnabled = prefs.isAutoZoomEnabled,
                            isSoundEnabled = prefs.isSoundEnabled,
                            language = prefs.preferredLanguage
                        )
                    }
                    autoZoomController.isEnabled = prefs.isAutoZoomEnabled
                    audioSynthesizer.isMuted = !prefs.isSoundEnabled
                } else {
                    db.savePreferences(UserTrackingPreferences())
                }
            }
        }

        viewModelScope.launch {
            db.getAllMemories().collect { list ->
                _uiState.update { it.copy(memoryItems = list) }
            }
        }
    }

    fun onLensesDiscovered(lenses: List<PhysicalCameraLens>, initial: PhysicalCameraLens?) {
        _uiState.update { it.copy(availableLenses = lenses, currentLens = initial) }
    }

    fun setZoomBounds(minZoom: Float, maxZoom: Float, currentZoom: Float) {
        autoZoomController.minHardwareZoomRatio = minZoom
        autoZoomController.maxHardwareZoomRatio = maxZoom
        autoZoomController.currentHardwareZoomRatio = currentZoom
        _uiState.update { it.copy(minZoom = minZoom, maxZoom = maxZoom, zoomRatio = currentZoom) }
    }

    fun onFrameAnalyzed(
        detected: List<DetectedTarget>,
        sensorWidth: Int,
        sensorHeight: Int,
        applyZoomToCamera: (Float) -> Unit,
        triggerAutoPhoto: () -> Unit
    ) {
        val track = targetTracker.processFrame(detected)
        val now = System.currentTimeMillis()
        if (track?.state == TrackingState.LOCKED && track.missedFrames == 0) {
            if (lockedSince == 0L) lockedSince = now
        } else {
            lockedSince = 0L
        }

        _uiState.update {
            it.copy(
                activeTrack = track,
                detectedCount = detected.size,
                statusMessage = when (track?.state) {
                    TrackingState.LOCKED -> if (it.language == "AZ") "HƏDƏF KİLİDLƏNDİ" else "TARGET LOCKED"
                    TrackingState.LOST -> if (it.language == "AZ") "HƏDƏF İTİRİLDİ (AXTARILIR)" else "TARGET LOST (SEARCHING)"
                    else -> if (it.language == "AZ") "Gözləmədə" else "Idle"
                }
            )
        }

        if (autoZoomController.isEnabled && track != null) {
            val (newZoom, velocity) = autoZoomController.calculateTargetZoom(
                track.rect,
                sensorWidth.toFloat(),
                sensorHeight.toFloat(),
                track.state
            )

            if (newZoom != autoZoomController.currentHardwareZoomRatio) {
                autoZoomController.currentHardwareZoomRatio = newZoom
                applyZoomToCamera(newZoom)
                _uiState.update { it.copy(zoomRatio = newZoom) }
                audioSynthesizer.updateMotorSpeed(velocity)
            } else {
                audioSynthesizer.updateMotorSpeed(0f)
            }
        } else {
            audioSynthesizer.updateMotorSpeed(0f)
        }

        if (_uiState.value.isAutoCaptureEnabled && track?.state == TrackingState.LOCKED) {
            if (lockedSince != 0L && now - lockedSince >= 800L &&
                now - lastAutoCaptureTime > 3500L && track.confidence > 0.70f) {
                lastAutoCaptureTime = now
                triggerAutoPhoto()
            }
        }
    }

    fun onScreenTapped(tapPoint: PointF, currentCandidates: List<DetectedTarget>) {
        lockedSince = 0L
        val success = targetTracker.selectTargetAt(tapPoint, currentCandidates)
        if (success) {
            trackingStartTime = System.currentTimeMillis()
        }
    }

    fun unlockTarget() {
        lockedSince = 0L
        val currentTrack = _uiState.value.activeTrack
        if (currentTrack != null && _uiState.value.isAiMemoryEnabled) {
            val duration = System.currentTimeMillis() - trackingStartTime
            if (duration > 1500L) {
                viewModelScope.launch {
                    db.insertMemory(
                        TrackingMemoryEntity(
                            targetType = currentTrack.label,
                            initialConfidence = currentTrack.confidence,
                            averageZoomLevel = _uiState.value.zoomRatio,
                            trackedDurationMs = duration,
                            lastKnownAspectRatio = currentTrack.rect.width() / currentTrack.rect.height()
                        )
                    )
                }
            }
        }
        targetTracker.cancelTracking()
        _uiState.update { it.copy(activeTrack = null) }
    }

    fun setManualZoom(zoom: Float, applyZoomToCamera: (Float) -> Unit) {
        autoZoomController.currentHardwareZoomRatio = zoom
        applyZoomToCamera(zoom)
        _uiState.update { it.copy(zoomRatio = zoom) }
    }

    fun toggleAutoZoom() {
        val newState = !_uiState.value.isAutoZoomEnabled
        autoZoomController.isEnabled = newState
        _uiState.update { it.copy(isAutoZoomEnabled = newState) }
        savePreferences()
    }

    fun toggleSound() {
        val newState = !_uiState.value.isSoundEnabled
        audioSynthesizer.isMuted = !newState
        _uiState.update { it.copy(isSoundEnabled = newState) }
        savePreferences()
    }

    fun toggleAiMemory() {
        _uiState.update { it.copy(isAiMemoryEnabled = !it.isAiMemoryEnabled) }
        savePreferences()
    }

    fun toggleAutoCapture() {
        _uiState.update { it.copy(isAutoCaptureEnabled = !it.isAutoCaptureEnabled) }
    }

    fun toggleLanguage() {
        val nextLang = if (_uiState.value.language == "AZ") "EN" else "AZ"
        _uiState.update { it.copy(language = nextLang) }
        savePreferences()
    }

    private fun savePreferences() {
        val state = _uiState.value
        viewModelScope.launch {
            db.savePreferences(UserTrackingPreferences(
                isAiMemoryEnabled = state.isAiMemoryEnabled,
                isAutoZoomEnabled = state.isAutoZoomEnabled,
                isSoundEnabled = state.isSoundEnabled,
                preferredLanguage = state.language
            ))
        }
    }

    fun clearMemory() {
        viewModelScope.launch {
            db.clearMemories()
        }
    }

    fun updateRecordingState(isRec: Boolean) {
        _uiState.update { it.copy(isRecording = isRec) }
    }

    override fun onCleared() {
        super.onCleared()
        audioSynthesizer.release()
    }
}
