package com.aicameratracking.pro.camera

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.provider.MediaStore
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

data class PhysicalCameraLens(
    val id: String,
    val title: String,
    val selector: CameraSelector,
    val zoomFactor: Float
)

class CameraManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner
) {
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null

    private var pendingSurfaceProvider: Preview.SurfaceProvider? = null
    private var preview: Preview? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null

    var currentLensFacing: Int = CameraSelector.LENS_FACING_BACK
    var currentLens: PhysicalCameraLens? = null

    fun initialize(
        analyzer: ImageAnalysis.Analyzer,
        onInitialized: (List<PhysicalCameraLens>) -> Unit
    ) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            val lenses = querySupportedLenses(cameraProvider!!)
            currentLens = lenses.firstOrNull { it.zoomFactor == 1.0f } ?: lenses.firstOrNull()
            startCamera(currentLens?.selector ?: CameraSelector.DEFAULT_BACK_CAMERA, analyzer)
            onInitialized(lenses)
        }, ContextCompat.getMainExecutor(context))
    }

    private fun querySupportedLenses(provider: ProcessCameraProvider): List<PhysicalCameraLens> {
        val lensList = mutableListOf<PhysicalCameraLens>()

        if (provider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
            lensList.add(PhysicalCameraLens("back_1x", "1.0x", CameraSelector.DEFAULT_BACK_CAMERA, 1.0f))
        }

        // CameraX default back lens may select a logical multi-camera device.
        // Do not advertise wide/tele lenses without a working camera-ID selector.

        if (provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
            lensList.add(PhysicalCameraLens("front", "Ön (Front)", CameraSelector.DEFAULT_FRONT_CAMERA, 1.0f))
        }

        return lensList
    }

    @OptIn(ExperimentalCamera2Interop::class)
    fun startCamera(cameraSelector: CameraSelector, analyzer: ImageAnalysis.Analyzer) {
        val provider = cameraProvider ?: return
        activeRecording?.stop()
        activeRecording = null
        provider.unbindAll()
        currentLensFacing = cameraSelector.lensFacing ?: CameraSelector.LENS_FACING_BACK

        val previewBuilder = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_16_9)
        val extPreview = Camera2Interop.Extender(previewBuilder)
        extPreview.setCaptureRequestOption(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
        )
        val previewUseCase = previewBuilder.build().also { useCase ->
            pendingSurfaceProvider?.let { useCase.setSurfaceProvider(it) }
        }
        preview = previewUseCase

        val analysisUseCase = ImageAnalysis.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_16_9)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .build().also {
                it.setAnalyzer(cameraExecutor, analyzer)
            }
        imageAnalysis = analysisUseCase

        val photoUseCase = ImageCapture.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_16_9)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
        imageCapture = photoUseCase

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
            .build()
        val videoUseCase = VideoCapture.withOutput(recorder)
        videoCapture = videoUseCase

        try {
            // Some camera devices cannot simultaneously bind four use cases.
            // First attempt full functionality, then gracefully fall back to
            // live detection and still photography without a video recorder.
            camera = provider.bindToLifecycle(
                lifecycleOwner, cameraSelector,
                previewUseCase, analysisUseCase, photoUseCase, videoUseCase
            )
        } catch (fullBindError: Exception) {
            provider.unbindAll()
            videoCapture = null
            try {
                camera = provider.bindToLifecycle(
                    lifecycleOwner, cameraSelector,
                    previewUseCase, analysisUseCase, photoUseCase
                )
            } catch (fallbackError: Exception) {
                android.util.Log.e("AICamera", "Camera initialization failed", fallbackError)
                camera = null
            }
        }
    }

    fun setSurfaceProvider(surfaceProvider: Preview.SurfaceProvider) {
        pendingSurfaceProvider = surfaceProvider
        preview?.setSurfaceProvider(surfaceProvider)
    }

    fun setZoomRatio(ratio: Float) {
        val limits = camera?.cameraInfo?.zoomState?.value
        val safe = if (limits == null) ratio else ratio.coerceIn(limits.minZoomRatio, limits.maxZoomRatio)
        camera?.cameraControl?.setZoomRatio(safe)
    }

    fun getZoomState() = camera?.cameraInfo?.zoomState

    fun takePhoto(onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        val capture = imageCapture ?: return
        val fileName = "IMG_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/AICameraTracking")
            }
        }

        val outputOptions = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    onSuccess(fileName)
                }

                override fun onError(exception: ImageCaptureException) {
                    onError(exception.message ?: "Capture failed")
                }
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun toggleRecording(
        onStarted: () -> Unit,
        onFinalized: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val vc = videoCapture ?: run {
            onError("Video is not supported with simultaneous tracking on this camera")
            return
        }

        if (activeRecording != null) {
            activeRecording?.stop()
            activeRecording = null
            return
        }

        val fileName = "VID_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.mp4"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AICameraTracking")
            }
        }

        val mediaStoreOutputOptions = MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(contentValues).build()

        activeRecording = vc.output
            .prepareRecording(context, mediaStoreOutputOptions)
            .apply {
                try {
                    withAudioEnabled()
                } catch (_: SecurityException) {}
            }
            .start(ContextCompat.getMainExecutor(context)) { recordEvent ->
                when (recordEvent) {
                    is VideoRecordEvent.Start -> onStarted()
                    is VideoRecordEvent.Finalize -> {
                        if (!recordEvent.hasError()) {
                            onFinalized(fileName)
                        } else {
                            onError(recordEvent.cause?.message ?: "Recording error")
                        }
                        activeRecording = null
                    }
                }
            }
    }

    fun isRecording(): Boolean = activeRecording != null

    fun release() {
        activeRecording?.stop()
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
    }
}
