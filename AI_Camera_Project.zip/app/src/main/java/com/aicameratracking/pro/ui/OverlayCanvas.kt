package com.aicameratracking.pro.ui

import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.unit.sp
import com.aicameratracking.pro.camera.CoordinateTransformer
import com.aicameratracking.pro.tracking.ActiveTrack
import com.aicameratracking.pro.tracking.DetectedTarget
import com.aicameratracking.pro.tracking.TrackingState

@Composable
fun OverlayCanvas(
    activeTrack: ActiveTrack?,
    allDetected: List<DetectedTarget>,
    sensorWidth: Int,
    sensorHeight: Int,
    isFrontCamera: Boolean,
    onTap: (PointF, Float) -> Unit,
    textMeasurer: TextMeasurer
) {
    // Frame results arrive frequently. Do not restart the pointer gesture recognizer
    // on every Compose recomposition or an in-flight touch may be cancelled.
    val latestTap = rememberUpdatedState(onTap)
    val latestSourceWidth = rememberUpdatedState(sensorWidth)
    val latestSourceHeight = rememberUpdatedState(sensorHeight)
    val latestIsFrontCamera = rememberUpdatedState(isFrontCamera)
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val w = latestSourceWidth.value
                    val h = latestSourceHeight.value
                    if (w > 0 && h > 0 && size.width > 0 && size.height > 0) {
                        val sx = size.width.toFloat() / w.toFloat()
                        val sy = size.height.toFloat() / h.toFloat()
                        val scale = maxOf(sx, sy)
                        val tolerance = (minOf(size.width, size.height).toFloat() * 0.035f / scale)
                            .coerceIn(8f, 55f)
                        val sourcePoint = CoordinateTransformer.inversePoint(
                            offset.x, offset.y, w.toFloat(), h.toFloat(),
                            size.width.toFloat(), size.height.toFloat(), latestIsFrontCamera.value
                        )
                        latestTap.value(sourcePoint, tolerance)
                    }
                }
            }
    ) {
        val canvasWidth = size.width
        val canvasHeight = size.height

        if (sensorWidth <= 0 || sensorHeight <= 0) return@Canvas

        for (candidate in allDetected) {
            val mappedRect = CoordinateTransformer.transformRect(
                candidate.boundingBox,
                sensorWidth.toFloat(),
                sensorHeight.toFloat(),
                canvasWidth,
                canvasHeight,
                isFrontCamera
            )

            drawRect(
                color = Color.Cyan.copy(alpha = 0.35f),
                topLeft = Offset(mappedRect.left, mappedRect.top),
                size = Size(mappedRect.width(), mappedRect.height()),
                style = Stroke(width = 2f)
            )
        }

        activeTrack?.let { track ->
            val mapped = CoordinateTransformer.transformRect(
                track.rect,
                sensorWidth.toFloat(),
                sensorHeight.toFloat(),
                canvasWidth,
                canvasHeight,
                isFrontCamera
            )

            val boxColor = when (track.state) {
                TrackingState.LOCKED -> Color(0xFF00E676)
                TrackingState.LOST -> Color(0xFFFF3D00)
                else -> Color.Yellow
            }

            val bracketLen = minOf(mapped.width(), mapped.height()) * 0.25f
            val path = Path().apply {
                moveTo(mapped.left, mapped.top + bracketLen)
                lineTo(mapped.left, mapped.top)
                lineTo(mapped.left + bracketLen, mapped.top)

                moveTo(mapped.right - bracketLen, mapped.top)
                lineTo(mapped.right, mapped.top)
                lineTo(mapped.right + bracketLen, mapped.top)

                moveTo(mapped.right, mapped.bottom - bracketLen)
                lineTo(mapped.right, mapped.bottom)
                lineTo(mapped.right - bracketLen, mapped.bottom)

                moveTo(mapped.left + bracketLen, mapped.bottom)
                lineTo(mapped.left, mapped.bottom)
                lineTo(mapped.left, mapped.bottom - bracketLen)
            }

            drawPath(path = path, color = boxColor, style = Stroke(width = 6f))

            // CameraX hardware zoom uses the optical center. An unobtrusive visual
            // guidance line helps the photographer aim the phone toward the target.
            if (track.state == TrackingState.LOCKED) {
                val center = Offset(canvasWidth / 2f, canvasHeight / 2f)
                val target = Offset(mapped.centerX(), mapped.centerY())
                val distance = kotlin.math.hypot(target.x - center.x, target.y - center.y)
                if (distance > canvasWidth * 0.16f) {
                    drawLine(
                        color = Color.Yellow.copy(alpha = 0.8f),
                        start = target,
                        end = center,
                        strokeWidth = 2f
                    )
                    drawCircle(Color.Yellow.copy(alpha = 0.85f), radius = 7f, center = center)
                }
            }

            val cx = mapped.centerX()
            val cy = mapped.centerY()
            drawLine(boxColor, Offset(cx - 16f, cy), Offset(cx + 16f, cy), strokeWidth = 3f)
            drawLine(boxColor, Offset(cx, cy - 16f), Offset(cx, cy + 16f), strokeWidth = 3f)

            val infoText = if (track.state == TrackingState.LOST) {
                "TARGET LOST"
            } else {
                "${track.label} [${(track.confidence * 100).toInt()}%]"
            }

            val textResult = textMeasurer.measure(
                AnnotatedString(infoText),
                style = TextStyle(color = Color.White, fontSize = 13.sp)
            )

            val textBgTop = (mapped.top - 46f).coerceAtLeast(10f)
            drawRect(
                color = boxColor.copy(alpha = 0.85f),
                topLeft = Offset(mapped.left, textBgTop),
                size = Size(textResult.size.width + 24f, 40f)
            )

            drawText(
                textLayoutResult = textResult,
                topLeft = Offset(mapped.left + 12f, textBgTop + 6f)
            )
        }
    }
}
