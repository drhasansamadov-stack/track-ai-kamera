package com.aicameratracking.pro.tracking

import android.graphics.RectF
import kotlin.math.abs

class AutoZoomController {
    var isEnabled: Boolean = true
    var currentHardwareZoomRatio: Float = 1.0f
    var minHardwareZoomRatio: Float = 1.0f
    var maxHardwareZoomRatio: Float = 10.0f

    private val targetViewportFraction = 0.33f
    private val deadzone = 0.035f
    private var lastZoomVelocity = 0.0f

    fun calculateTargetZoom(
        targetRect: RectF?,
        screenWidth: Float,
        screenHeight: Float,
        trackingState: TrackingState
    ): Pair<Float, Float> {
        if (!isEnabled || targetRect == null || trackingState == TrackingState.IDLE) {
            lastZoomVelocity = 0f
            return Pair(currentHardwareZoomRatio, 0f)
        }

        if (trackingState == TrackingState.LOST) {
            val step = (currentHardwareZoomRatio - 1.0f) * 0.08f
            val newRatio = (currentHardwareZoomRatio - step).coerceAtLeast(minHardwareZoomRatio)
            val velocity = newRatio - currentHardwareZoomRatio
            lastZoomVelocity = velocity
            return Pair(newRatio, velocity)
        }

        val targetLongestSide = maxOf(targetRect.width(), targetRect.height())
        val screenLongestSide = maxOf(screenWidth, screenHeight)

        val currentOccupiedFraction = targetLongestSide / screenLongestSide
        val fractionError = targetViewportFraction - currentOccupiedFraction

        if (abs(fractionError) <= deadzone) {
            lastZoomVelocity = 0f
            return Pair(currentHardwareZoomRatio, 0f)
        }

        val rawZoomAdjustment = (fractionError * currentHardwareZoomRatio * 0.45f)
        val clampedVelocity = rawZoomAdjustment.coerceIn(-0.18f, 0.22f)
        val smoothedVelocity = (lastZoomVelocity * 0.4f) + (clampedVelocity * 0.6f)
        lastZoomVelocity = smoothedVelocity

        val requestedZoom = (currentHardwareZoomRatio + smoothedVelocity).coerceIn(
            minHardwareZoomRatio,
            maxHardwareZoomRatio
        )

        return Pair(requestedZoom, smoothedVelocity)
    }
}
