package com.aicameratracking.pro.tracking

import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * An adaptive crop controller. Coordinates supplied by ImageAnalysis refer to the
 * CURRENT cropped field of view. We integrate errors incrementally rather than
 * treating the detected position as a static full-sensor coordinate.
 *
 * Camera2's sensor crop may be ignored or overridden by CameraX on some devices;
 * callers must treat this as experimental and perform physical-camera testing.
 */
data class FramingState(val centerX: Float, val centerY: Float, val zoom: Float)

class AutoFramingController {
    private var state = FramingState(0.5f, 0.5f, 1f)
    private var lastNs = 0L
    var minZoom: Float = 1f
    var maxZoom: Float = 8f

    fun reset() {
        state = FramingState(0.5f, 0.5f, minZoom)
        lastNs = 0L
    }

    fun state(): FramingState = state

    fun setZoom(value: Float) {
        state = clamp(FramingState(state.centerX, state.centerY, value.coerceIn(minZoom, maxZoom)))
    }

    fun update(rect: RectF?, frameWidth: Int, frameHeight: Int,
               trackingState: TrackingState, nowNs: Long = System.nanoTime()): FramingState {
        val dt = if (lastNs == 0L) 0.033f else ((nowNs - lastNs) / 1_000_000_000f).coerceIn(0.008f, 0.1f)
        lastNs = nowNs
        if (frameWidth < 1 || frameHeight < 1 || rect == null || trackingState != TrackingState.LOCKED ||
            rect.width() <= 1f || rect.height() <= 1f) {
            // Hold the last framing during occlusions rather than panning on guessed boxes.
            return state
        }

        val rx = (rect.centerX() / frameWidth - 0.5f).coerceIn(-0.5f, 0.5f)
        val ry = (rect.centerY() / frameHeight - 0.5f).coerceIn(-0.5f, 0.5f)
        val frameFraction = max(rect.width() / frameWidth, rect.height() / frameHeight)
        if (!rx.isFinite() || !ry.isFinite() || !frameFraction.isFinite() || frameFraction <= 0f) return state

        // Dead-zone keeps tiny detector jitter from shaking the recording.
        val dead = 0.026f
        val dx = if (abs(rx) <= dead) 0f else rx - (if (rx > 0f) dead else -dead)
        val dy = if (abs(ry) <= dead) 0f else ry - (if (ry > 0f) dead else -dead)

        // Create a little crop margin first: at 1x there is no room for pan.
        // Cap the preparatory zoom so an off-center subject cannot disappear.
        val desired = (state.zoom * 0.33f / frameFraction).coerceIn(minZoom, maxZoom)
        val maxZoomStep = max(0.015f, state.zoom * 0.42f * dt)
        val zoomError = desired - state.zoom
        val farFromCenter = abs(rx) > 0.13f || abs(ry) > 0.13f
        val zoomStep = when {
            zoomError < 0f -> zoomError.coerceAtLeast(-maxZoomStep * 1.6f)
            farFromCenter && state.zoom >= 1.45f -> 0f
            frameFraction in 0.30f..0.36f -> 0f
            else -> zoomError.coerceAtMost(maxZoomStep)
        }
        val zoom = (state.zoom + zoomStep).coerceIn(minZoom, maxZoom)

        // Limit pan motion to ~0.9 visible viewport per second, with damping.
        val maxMove = (0.90f * dt) / zoom
        val newX = state.centerX + (dx / zoom * 0.38f).coerceIn(-maxMove, maxMove)
        val newY = state.centerY + (dy / zoom * 0.38f).coerceIn(-maxMove, maxMove)
        state = clamp(FramingState(newX, newY, zoom))
        return state
    }

    private fun clamp(s: FramingState): FramingState {
        val half = 0.5f / s.zoom.coerceAtLeast(1f)
        return FramingState(
            s.centerX.coerceIn(half, 1f - half),
            s.centerY.coerceIn(half, 1f - half),
            s.zoom
        )
    }
}
