package com.aicameratracking.pro.tracking

import android.graphics.RectF
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import java.util.concurrent.atomic.AtomicBoolean

data class DetectedTarget(
    val boundingBox: RectF,
    val label: String,
    val confidence: Float,
    val trackingId: Int?
)

class ObjectDetectorPipeline(
    private val onTargetsDetected: (List<DetectedTarget>, Int, Int, Int) -> Unit
) : ImageAnalysis.Analyzer {

    private val isBusy = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val objectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build()
    )

    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .setMinFaceSize(0.1f)
            .build()
    )

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        if (isBusy.get()) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        isBusy.set(true)
        val rotationDegrees = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotationDegrees)

        scope.launch {
            val results = mutableListOf<DetectedTarget>()
            try {
                val objects = objectDetector.process(inputImage).await()
                for (obj in objects) {
                    val label = obj.labels.firstOrNull()?.text ?: "Obyekt"
                    val conf = obj.labels.firstOrNull()?.confidence ?: 0.6f
                    results.add(
                        DetectedTarget(
                            boundingBox = RectF(obj.boundingBox),
                            label = mapLabel(label),
                            confidence = conf,
                            trackingId = obj.trackingId
                        )
                    )
                }

                val faces = faceDetector.process(inputImage).await()
                for (face in faces) {
                    val faceRect = RectF(face.boundingBox)
                    val isDuplicate = results.any { calculateIoU(it.boundingBox, faceRect) > 0.45f }
                    if (!isDuplicate) {
                        results.add(
                            DetectedTarget(
                                boundingBox = faceRect,
                                label = "İnsan Üzü (Face)",
                                confidence = 0.95f,
                                trackingId = face.trackingId
                            )
                        )
                    }
                }

                val frameWidth = if (rotationDegrees == 90 || rotationDegrees == 270) imageProxy.height else imageProxy.width
                val frameHeight = if (rotationDegrees == 90 || rotationDegrees == 270) imageProxy.width else imageProxy.height

                withContext(Dispatchers.Main) {
                    onTargetsDetected(results, frameWidth, frameHeight, rotationDegrees)
                }
            } catch (error: Exception) {
                android.util.Log.e("AICamera", "Frame analysis failed", error)
            } finally {
                imageProxy.close()
                isBusy.set(false)
            }
        }
    }

    private fun mapLabel(rawLabel: String): String {
        return when (rawLabel.lowercase()) {
            "bird" -> "Quş (Bird)"
            "cat", "dog", "animal" -> "Heyvan (Animal)"
            "person" -> "İnsan (Person)"
            "vehicle", "car" -> "Avtomobil (Vehicle)"
            else -> rawLabel.replaceFirstChar { it.uppercase() }
        }
    }

    fun close() {
        scope.cancel()
        objectDetector.close()
        faceDetector.close()
    }

    companion object {
        fun calculateIoU(a: RectF, b: RectF): Float {
            val left = maxOf(a.left, b.left)
            val top = maxOf(a.top, b.top)
            val right = minOf(a.right, b.right)
            val bottom = minOf(a.bottom, b.bottom)

            val intersection = (right - left).coerceAtLeast(0f) * (bottom - top).coerceAtLeast(0f)
            val union = (a.width() * a.height()) + (b.width() * b.height()) - intersection
            return if (union > 0f) intersection / union else 0f
        }
    }
}
