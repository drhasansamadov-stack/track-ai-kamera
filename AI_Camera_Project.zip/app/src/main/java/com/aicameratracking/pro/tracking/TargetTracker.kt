package com.aicameratracking.pro.tracking

import android.graphics.PointF
import android.graphics.RectF
import com.aicameratracking.pro.tracking.ObjectDetectorPipeline.Companion.calculateIoU

enum class TrackingState {
    IDLE,
    SEARCHING,
    LOCKED,
    LOST
}

data class ActiveTrack(
    val rect: RectF,
    val label: String,
    val confidence: Float,
    val state: TrackingState,
    val missedFrames: Int
)

class TargetTracker {
    private var kalmanTracker: KalmanBoxTracker? = null
    private var lockedLabel: String = ""
    private var currentConfidence: Float = 0f
    private var missedFrames = 0
    private val maxToleratedMisses = 18

    var currentState: TrackingState = TrackingState.IDLE
        private set

    fun lockTarget(rect: RectF, label: String, confidence: Float) {
        kalmanTracker = KalmanBoxTracker(rect)
        lockedLabel = label
        currentConfidence = confidence
        missedFrames = 0
        currentState = TrackingState.LOCKED
    }

    fun selectTargetAt(tapPoint: PointF, detectedTargets: List<DetectedTarget>): Boolean {
        val hit = detectedTargets.firstOrNull { it.boundingBox.contains(tapPoint.x, tapPoint.y) }
        return if (hit != null) {
            lockTarget(hit.boundingBox, hit.label, hit.confidence)
            true
        } else {
            // Do not advertise a tracking lock without an actual detection.
            // Arbitrary region tracking needs a separately implemented visual tracker.
            false
        }
    }

    fun cancelTracking() {
        kalmanTracker = null
        currentState = TrackingState.IDLE
        missedFrames = 0
    }

    fun processFrame(detectedTargets: List<DetectedTarget>): ActiveTrack? {
        val tracker = kalmanTracker ?: return null
        val predictedRect = tracker.predict()

        var bestMatch: DetectedTarget? = null
        var maxScore = 0.0f

        for (candidate in detectedTargets) {
            val iou = calculateIoU(predictedRect, candidate.boundingBox)
            val labelMatchBonus = if (candidate.label == lockedLabel) 0.25f else 0.0f
            val score = iou + labelMatchBonus

            if (score > maxScore && iou > 0.22f) {
                maxScore = score
                bestMatch = candidate
            }
        }

        if (bestMatch != null) {
            tracker.update(bestMatch.boundingBox)
            currentConfidence = (currentConfidence * 0.7f) + (bestMatch.confidence * 0.3f)
            missedFrames = 0
            currentState = TrackingState.LOCKED
        } else {
            missedFrames++
            if (missedFrames > maxToleratedMisses) {
                currentState = TrackingState.LOST
            }
        }

        return ActiveTrack(
            rect = tracker.getEstimatedRect(),
            label = lockedLabel,
            confidence = currentConfidence,
            state = currentState,
            missedFrames = missedFrames
        )
    }
}
